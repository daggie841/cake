<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once 'user-header.php';
include_once 'Cart.php';

$ct = new Cart();

// Initialize variables
$qty = 0;
$sum = 0;

if (isset($_GET['delpro'])) {
    $delId = preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['delpro']);
    $delProduct = $ct->delProductByCart($delId);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['catId'])) {
    $catId = $_POST['catId'];
    $quantity = $_POST['quantity'];
    $updateCart = $ct->updateCartQuantity($catId, $quantity);

    if ($quantity <= 0) {
        $delProduct = $ct->delProductByCart($catId);
    }
}

if (!isset($_GET['id'])) {
    echo "<meta http-equiv='refresh' content='0;URL=?id=nayem' />";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart</title>
    <style>
        .content {
            padding: 20px;
        }
        .cartoption {
            margin-bottom: 20px;
        }
        .cartpage {
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .message {
            background-color: #dff0d8;
            border: 1px solid #d6e9c6;
            color: #3c763d;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
        }
        .table-container {
            overflow-x: auto;
        }
        table.tblone {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table.tblone th, table.tblone td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        table.tblone th {
            background-color: #f2f2f2;
        }
        table.tblone td img {
            max-width: 100%;
            height: auto;
        }
        .shopping {
            margin-top: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .shopleft, .shopright {
            text-align: center;
        }
        .shopleft a, .shopright a {
            display: inline-block;
            padding: 7px 10px;
            background-color: orange;
            color: black;
            text-decoration: none;
            border-radius: 5px;
        }
        .shopleft a:hover, .shopright a:hover {
            background-color: green;
        }
        .clear {
            clear: both;
        }
        .total-row {
            font-weight: bold;
            background-color: #f9f9f9;
        }
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .main {
                width: 100%;
            }
            .shopleft a, .shopright a {
                font-size: 10px;
                font-weight: bold;
            }
        }
    </style>
    <script>
        function showAlert(message) {
            alert(message);
        }
    </script>
</head>
<body>
    <?php if (!empty($cartActionMessage)) : ?>
        <script>
            showAlert("<?php echo $cartActionMessage; ?>");
        </script>
    <?php endif; ?>

    <div class="main">
        <div class="content">
            <div class="cartoption">       
                <div class="cartpage shopping-content">
                    <h2>Your Cart</h2>
                    <?php 
                    if (!empty($updateCartMessage)) {
                        echo '<div class="message">' . $updateCartMessage . '</div>';
                    }

                    if (!empty($deleteProductMessage)) {
                        echo '<div class="message">' . $deleteProductMessage . '</div>';
                    }
                    ?>

                    <div class="table-container">
                        <table class="tblone">
                            <tr>
                                <th width="5%">SL</th>
                                <th width="25%">Product Name</th>
                                <th width="8%">Image</th>
                                <th width="10%">Price</th>
                                <th width="8%">Quantity</th>
                                <th width="15%">Total Price</th>
                                <th width="4%">Action</th>
                            </tr>
                            <?php 
                            $getPro = $ct->getCartProduct();
                            if ($getPro) {
                                $i = 0;
                                while ($result = $getPro->fetch_assoc()) {
                                    $i++;
                                    $total = $result['price'] * $result['quantity'];
                                    $qty += $result['quantity'];
                                    $sum += $total;
                            ?>
                            <tr>
                                <td><?php echo $i; ?></td>
                                <td><?php echo $result['productName']; ?></td>
                                <td><img src="<?php echo htmlspecialchars($result['image']); ?>" width="50"/></td>
                                <td>KSH. <?php echo $result['price']; ?></td>
                                <td>
                                    <form action="" method="post">
                                        <input type="hidden" name="catId" value="<?php echo $result['catId']; ?>"/>
                                        <input type="number" name="quantity" value="<?php echo $result['quantity']; ?>"/>
                                        <input type="submit" name="submit" value="Update"/>
                                    </form>
                                </td>
                                <td>KSH. <?php echo $total; ?></td>
                                <td><a onclick="return confirm('Are you sure to delete?')" href="?delpro=<?php echo $result['catId']; ?>">X</a></td>
                            </tr>
                            <?php 
                                } 
                            } 
                            ?>
                            <tr class="total-row">
                                <td colspan="4">Total:</td>
                                <td><?php echo $qty; ?></td>
                                <td>KSH. <?php echo $sum; ?></td>
                                <td></td>
                            </tr>
                        </table>
                    </div>

                    <?php
                    $getData = $ct->checkCartTable();
                    if ($getData) {
                    ?>
                   
                    <?php } else {
                        echo "Cart is Empty! Add item to cart...";
                    } ?>
                </div>
                <div class="shopping">
                    <div class="shopleft">
                        <a href="shop.php">CONTINUE SHOPPING</a>
                    </div>
                    <div class="shopright">
                        <?php if ($getData) { ?>
                            <a href="payment.php">BUY NOW</a>
                        <?php } else { ?>
                            <!-- Add item to view cart message when cart is empty -->
                        <?php } ?>
                    </div>
                </div>
            </div>      
            <div class="clear"></div>
        </div>
    </div>

    <?php include 'footer.php'; ?>
</body>
</html>
