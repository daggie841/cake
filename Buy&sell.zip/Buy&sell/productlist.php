<?php 
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'admin-header.php'; 
include_once 'Formate.php'; 
include_once 'Product.php'; 

$fm = new Format();
$pd = new Product();


?>

<!DOCTYPE html>
<html lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<body>
<div class="grid_10">
    <div class="box round first grid">
        <h2>Product List</h2>
        <div class="block">

            <table class="responsive-table" id="example">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Product Name</th>
                        <th>Category</th>
                        <th>Description</th>
                        <th>Price</th>
                        <th>N.shop</th>
                        <th>Image</th>
                        <th>Phone</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>

                    <?php
                    $getPd = $pd->getAllProducts();
                    if ($getPd) {
                        $i = 0;
                        while ($result = $getPd->fetch_assoc()) {
                            $i++;
                    ?>

                            <tr>
                                <td data-label="No"><?php echo $i; ?></td>
                                <td data-label="Product Name"><?php echo $result['productName']; ?></td>
                                <td data-label="Category"><?php echo $result['catName']; ?></td>
                                <td data-label="Description"><?php echo $fm->textShorten($result['body'], 100); ?></td>
                                <td data-label="Price">Ksh.<?php echo $result['price']; ?></td>
                                <td data-label="shopName"><?php echo $result['shopname']; ?></td>
                                <td data-label="Image"><img src="<?php echo $result['image']; ?>" height="40px" width="60px"></td>
                                 <td data-label="phone"><?php echo $result['phone']; ?></td>
                                <td data-label="Action"><a href="productedit.php?proid=<?php echo $result['productId']; ?>">Edit</a> || <a onclick="return confirm('Are you sure to delete!')" href="?delpro=<?php echo $result['productId']; ?>">Delete</a></td>
                            </tr>

                    <?php
                        }
                    }
                    ?>

                </tbody>
            </table>

        </div>
    </div>
</div>

<?php include 'adminfooter.php'; ?>

<style>
    .responsive-table {
        width: 100%;
        margin: 20px 0;
        border-collapse: collapse;
    }

    .responsive-table th,
    .responsive-table td {
        border: 1px solid #ddd;
        padding: 14px;
        text-align: left;
    }

    .responsive-table th {
        background-color: #f2f2f2;
    }

    @media screen and (max-width: 600px) {
        .responsive-table thead,
        .responsive-table tbody,
        .responsive-table th,
        .responsive-table td,
        .responsive-table tr {
            display: block;
        }

        .responsive-table thead tr {
            position: fixed;
            top: -9999px;
            left: -9999px;
        }

        .responsive-table tr {
            border: 4px solid #ccc;
        }

        .responsive-table td {
            border: none;
            border-bottom: 1px solid #eee;
            position: relative;
            padding-left: 50%;
            text-align: left;
        }

        .responsive-table td:before {
            position: absolute;
            top: 6px;
            left: 6px;
            width: 45%;
            padding-right: 10px;
            white-space: nowrap;
            content: attr(data-label);
            font-weight: bold;
        }
    }
</style>

</body>
</html>
