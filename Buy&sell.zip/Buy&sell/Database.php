
<?php
include_once 'config.php';

class Database {
    public $link;
    private $error;

    public function __construct() {
        $this->connectDB();
    }

    private function connectDB() {
        $this->link = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($this->link->connect_error) {
            $this->error = "Connection failed: " . $this->link->connect_error;
            return false;
        }
        return true;
    }

    public function getLink() {
        return $this->link;
    }

    public function escapeString($string) {
        return mysqli_real_escape_string($this->link, $string);
    }

    public function select($query) {
        $result = $this->link->query($query);
        if ($result === false) {
            $this->error = "Error: " . $this->link->error . " | Query: " . $query;
            return false;
        } elseif ($result->num_rows > 0) {
            return $result;
        } else {
            return false;
        }
    }

    public function insert($query) {
        $insert_row = $this->link->query($query);
        if ($insert_row === false) {
            $this->error = "Error: " . $this->link->error . " | Query: " . $query;
            return false;
        } else {
            return $this->link->insert_id;
        }
    }

    public function update($query) {
        $update_row = $this->link->query($query);
        if ($update_row === false) {
            $this->error = "Error: " . $this->link->error . " | Query: " . $query;
            return false;
        } else {
            return true;
        }
    }

    public function delete($query) {
        $delete_row = $this->link->query($query);
        if ($delete_row === false) {
            $this->error = "Error: " . $this->link->error . " | Query: " . $query;
            return false;
        } else {
            return true;
        }
    }

    public function getError() {
        return $this->error;
    }

    public function __destruct() {
        $this->link->close();
    }
}
?>
