<?php
// fetch_items.php
include_once 'config.php';

if (isset($_GET['shopname']) && isset($_GET['admin_id'])) {
    $shopname = $_GET['shopname'];
    $admin_id = $_GET['admin_id'];

    // Database connection
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $stmt = $conn->prepare('SELECT * FROM tbl_product WHERE shopname = ? AND admin_id = ?');
    $stmt->bind_param('si', $shopname, $admin_id);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($product = $result->fetch_assoc()) {
        echo '<div class="product">';
        echo '<h2>' . htmlspecialchars($product['product_name']) . '</h2>';
        echo '<p>' . htmlspecialchars($product['description']) . '</p>';
        echo '<img src="uploads/' . htmlspecialchars($product['image']) . '" alt="' . htmlspecialchars($product['product_name']) . '">';
        echo '<p>Price: $' . htmlspecialchars($product['price']) . '</p>';
        echo '</div>';
    }

    $stmt->close();
    $conn->close();
}
?>
