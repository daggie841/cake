<?php include 'admin-header.php'; ?>
<?php include 'Database.php'; ?>
<?php include 'Formate.php'; ?>

<?php
if (!isset($_GET['msgid']) || $_GET['msgid'] == NULL) {
    echo "<script>window.location='admin_dashboard.php';</script>";
} else {
    $id = $_GET['msgid'];
}
?>

<div class="grid_10">
    <div class="box round first grid">
        <h2>View Message</h2>
        <?php 
        $db = new Database();
        $fm = new Format();
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $to = $fm->validation($_POST['toEmail']);
            $from = $fm->validation($_POST['fromEmail']);
            $subject = $fm->validation($_POST['subject']);
            $message = $fm->validation($_POST['message']);
            $headers = "From: " . $from;

            $sendmail = mail($to, $subject, $message, $headers);

            if ($sendmail) {
                echo "<span class='success'>Message sent Successfully.</span>";
            } else {
                echo "<span class='error'>Something went wrong!</span>";
            }
        }
        ?>

        <div class="block">               
            <form action="" method="post">
                <?php
                $query = "SELECT * FROM tbl_contact WHERE id='$id'";
                $msg = $db->select($query);
                if ($msg) {
                    while ($result = $msg->fetch_assoc()) {
                ?>
                <table class="form">
                    <tr>
                        <td><label>To</label></td>
                        <td>
                            <input type="text" readonly name="toEmail" value="<?php echo $result['email']; ?>" class="medium" />
                        </td>
                    </tr>
                    <tr>
                        <td><label>From</label></td>
                        <td>
                            <input type="email" name="fromEmail" required class="medium" />
                        </td>
                    </tr>
                    <tr>
                        <td><label>Subject</label></td>
                        <td>
                            <input type="text" name="subject" placeholder="Please Enter Your Subject" class="medium" required />
                        </td>
                    </tr>
                    <tr>
                        <td><label>Message</label></td>
                        <td>
                            <textarea class="tinymce" name="message" required></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <input type="submit" name="submit" value="Send" />
                        </td>
                    </tr>
                </table>
                <?php 
                    }
                } 
                ?>
            </form>
        </div>
    </div>
</div>

<style>
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}
.grid_10 {
    width: 100%;
    margin: 0 auto;
    padding: 0;
}
.box {
    background-color: #fff;
    border: 1px solid #ddd;
    padding: 0;
    border-radius: 5px;
}
.round {
    border-radius: 10px;
}
h2 {
    color: #333;
    margin-bottom: 20px;
}
.block {
    padding: 10px;
}
table.form {
    width: 50%;
}
table.form td {
    padding: 10px;
}
table.form input[type="text"], table.form input[type="email"], table.form textarea {
    width: 100%;
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 4px;
    box-sizing: border-box;
}
table.form input[type="submit"] {
    padding: 10px 15px;
    background-color: #5cb85c;
    border: none;
    color: white;
    cursor: pointer;
    border-radius: 4px;
}
table.form input[type="submit"]:hover {
    background-color: #4cae4c;
}
</style>

<?php include 'adminfooter.php'; ?>
