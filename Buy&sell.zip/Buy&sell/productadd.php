<?php
ob_start();
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'admin-header.php'; 
include_once 'config.php';

// Function to fetch categories
function getCategory($conn) {
    $sql = "SELECT catId, catName FROM tbl_category";
    $result = $conn->query($sql);
    $categories = [];
    if ($result === false) {
        echo "Error fetching categories: " . $conn->error;
    } elseif ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $categories[] = $row;
        }
    }
    return $categories;
}

// Function to get category name by ID
function getCategoryNameById($catId, $conn) {
    $stmt = $conn->prepare("SELECT catName FROM tbl_category WHERE catId = ?");
    $stmt->bind_param("i", $catId);
    $stmt->execute();
    $result = $stmt->get_result();
    $catName = null;
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $catName = $row['catName'];
    }
    $stmt->close();
    return $catName;
}

// Function to fetch shop names
function getShopNames($conn) {
    $sql = "SELECT admin_id, shopname FROM adminlogin";
    $result = $conn->query($sql);
    $shops = [];
    if ($result === false) {
        echo "Error fetching shop names: " . $conn->error;
    } elseif ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $shops[] = $row;
        }
    }
    return $shops;
}

// Function to get shop name by ID
function getShopNameById($admin_id, $conn) {
    $stmt = $conn->prepare("SELECT shopname FROM adminlogin WHERE admin_id = ?");
    $stmt->bind_param("i", $admin_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $shopname = null;
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $shopname = $row['shopname'];
    }
    $stmt->close();
    return $shopname;
}

// Function to add product
function addProduct($productName, $catId, $catName, $body, $price, $image, $phone, $admin_id, $shopname, $conn) {
    $stmt = $conn->prepare("INSERT INTO tbl_product (productName, catId, catName, body, price, image, phone, admin_id, shopname) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if ($stmt === false) {
        echo "Error preparing statement: " . $conn->error;
        return false;
    }

    $stmt->bind_param("sissdsiis", $productName, $catId, $catName, $body, $price, $image, $phone, $admin_id, $shopname);
    if (!$stmt->execute()) {
        echo "ERROR: Could not execute query: " . $stmt->error;
        $stmt->close();
        return false;
    }

    $inserted_id = $stmt->insert_id;
    $stmt->close();

    return $inserted_id;
}

// Fetch categories and shop names
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$categories = getCategory($conn);
$shops = getShopNames($conn);
if ($categories === null || $shops === null) {
    echo "Error fetching categories or shops.";
}

$conn->close();

// Form handling
if (isset($_POST['submit'])) {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $productName = $_POST['productName'] ?? '';
    $catId = $_POST['catId'] ?? null;
    $body = $_POST['body'] ?? '';
    $price = $_POST['price'] ?? 0;
    $phone = $_POST['phone'] ?? '';
    $admin_id = $_POST['admin_id'] ?? null;
    

    // Validate phone number
    if (!preg_match('/^\d{10}$/', $phone)) {
        echo "Invalid phone number. Please enter exactly 10 digits.";
        $conn->close();
        exit();
    }

    // Handle image upload
    $image = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $image_dir = 'image/';
        $image_name = basename($_FILES['image']['name']);
        $image_path = $image_dir . $image_name;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $image_path)) {
            $image = $image_name;
        } else {
            echo "Error moving uploaded file.";
        }
    }

    // Fetch catName based on catId
    if ($catId) {
        $catName = getCategoryNameById($catId, $conn);
        if ($catName === null) {
            echo "Error: Category not found.";
            $conn->close();
            exit();
        }
    } else {
        echo "Please select a category.";
        $conn->close();
        exit();
    }

    // Fetch shopname based on admin_id
    if ($admin_id) {
        $shopname = getShopNameById($admin_id, $conn); // Fixed this line to use $admin_id instead of $shopname
        if ($shopname === null) {
            echo "Error: Shop name not found.";
            $conn->close();
            exit();
        }
    } else {
        echo "Please select a shop name.";
        $conn->close();
        exit();
    }

    // Add product
    $productId = addProduct($productName, $catId, $catName, $body, $price, $image, $phone, $admin_id, $shopname, $conn);

    if ($productId) {
        header("Location: productlist.php?productId=$productId");
        exit();
    } else {
        echo "Error adding product.";
    }

    $conn->close();
}
ob_end_flush();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            margin-top: 0;
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: bold;
        }

        input[type="text"],
        input[type="number"],
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            margin-top: 5px;
        }

        input[type="file"] {
            margin-top: 5px;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .ic-dashboard {
            list-style-type: none;
            margin-top: 20px;
        }

        .ic-dashboard a {
            text-decoration: none;
            color: #333;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Add Product</h2>
        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="productName">Product Name:</label>
                <input type="text" id="productName" name="productName" required>
            </div>
            <div class="form-group">
                <label for="body">Description:</label>
                <textarea id="body" name="body" required></textarea>
            </div>
            <div class="form-group">
                <label for="price">Price:</label>
                <input type="number" id="price" name="price" required>
            </div>
            <div class="form-group">
                <label for="image">Image:</label>
                <input type="file" id="image" name="image" accept="image/*">
            </div>
            <div class="form-group">
                <label for="categorySelect">Item Category:</label>
                <select id="categorySelect" name="catId" required>
                    <option value="">Select a category</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= htmlspecialchars($category['catId']) ?>">
                            <?= htmlspecialchars($category['catName']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="shopSelect">Select Shop:</label>
                <select id="shopSelect" name="admin_id" required>
                    <option value="">Select a shop</option>
                    <?php foreach ($shops as $shop): ?>
                        <option value="<?= htmlspecialchars($shop['admin_id']) ?>">
                            <?= htmlspecialchars($shop['shopname']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="phone">Phone:</label>
                <input type="text" id="phone" name="phone" pattern="\d{10}" required>
            </div>
            <input type="submit" name="submit" value="Submit">
            <li class="ic-dashboard"><a href="admin_dashboard.php"><span>Back to Dashboard</span></a></li>
        </form>
    </div>
</body>
</html>
