<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Not logged in, redirect to login page
    header("Location: adminlogin.php");
    exit;
}


include 'admin-header.php'; ?>
<?php include 'Database.php'; ?>
<?php include 'Formate.php'; ?>

<div class="wrapper">
    <div class="grid_10">
        <div class="box round first grid">
            <h2>Inbox</h2>

<?php 
if (isset($_GET['seenid'])) {
    $seenid = $_GET['seenid'];

    $query = "UPDATE tbl_contact 
        SET
        status = '1'

        WHERE id = '$seenid'";
        $db = new Database();
        $updated_row = $db->update($query);

if ($updated_row) {

    echo "<span class='success'>Message sent to the seen box.</span>";
} else {

      echo "<span class='error'>Something Wrong!</span>";
}

}

?>
            <div class="block">        
                <table class="data display datatable" id="example">
                <thead>
                    <tr>
                        <th>Serial No.</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Message</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>

            <?php
            $db = new Database();
            $fm = new Format();
            $query = "select * from tbl_contact where status='0' order by id desc";
            $msg = $db->select($query);
            if ($msg) {

            $i=0;
            while ($result = $msg->fetch_assoc()) {
               $i++;

           ?>    


        <tr class="odd gradeX">
            <td><?php echo $i;?></td>
            <td><?php echo $result['name'];?></td>
            <td><?php echo $result['email'];?></td>
            <td><?php echo $result['contact'];?></td>
            <td><?php echo $fm->textShorten($result['message'],30);?></td>
            <td><?php echo $fm->formatDate($result['date']);?></td>
            <td>
                <a href="viewmsg.php?msgid=<?php echo $result['id'];?>">View</a> || 
                <a href="replymsg.php?msgid=<?php echo $result['id'];?>">Reply</a>||
                <a onclick="return confirm('Are you sure you want to delete the message?');" href="?seenid=<?php echo $result['id'];?>">Seen</a> 
            </td>
        </tr>
                        
                        <?php } } ?>
                </tbody>
            </table>
           </div>
        </div>
    </div>
</div>

<style>
    .wrapper {
        width: 100%;
        margin-left: auto;
        margin-right: auto;
        padding: 0px;
    }

    .grid_10 {
        width: 100%;
        padding: 0 10px; /* Add padding for better spacing on smaller screens */
    }

    .box {
        border: 1px solid #ddd;
        padding: 10px; /* Add padding for better spacing */
        background-color: #f9f9f9;
    }

    h2 {
        text-align: center;
        color: #333;
        font-size: 24px;
    }

    .success {
        color: green;
    }

    .error {
        color: red;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    table, th, td {
        border: 1px solid #ddd;
    }

    th, td {
        padding: 10px;
        text-align: left;
    }

    th {
        background-color: #f2f2f2;
    }

    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    a {
        color: #3498db;
        text-decoration: none;
    }

    a:hover {
        text-decoration: underline;
    }

    /* Responsive styles */
    @media only screen and (max-width: 768px) {
        .grid_10 {
            padding: 0 4px; /* Adjust padding for smaller screens */
        }
        table {
            font-size: 7px; /* Decrease font size for smaller screens */
            
        }
        td{4px}
    }
</style>


<?php include 'adminfooter.php'; ?>
