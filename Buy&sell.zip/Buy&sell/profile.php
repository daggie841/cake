<?php 
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include'user-header.php';

$login = $_SESSION["cuslogin"];
if (!$login) {
    header("Location:login.php");
    exit(); // Ensure that script stops execution after redirection
}

// Include the necessary file or instantiate $cmr directly
include_once "customer.php"; // Adjust path if necessary

// Ensure $cmr is initialized
$cmr = new Customer();

$id = $_SESSION["cmrId"];
$getdata = $cmr->getCustomerData($id);
?>
<style>
    .tblone{width: 550px;margin: 0 auto;border: 2px solid #ddd;margin-bottom: 10px;}
    .tblone tr td{text-align: justify;}    
</style>

<div class="main">
    <div class="content">
        <div class="section group">
            <?php 
            if ($getdata) {
                while ($result = $getdata->fetch_assoc()) {
            ?>
            <table class="tblone">
                <tr>
                    <td colspan="3"><h2>Your Profile Details</h2></td>
                </tr>
                <tr>
                    <td width="20%">Name</td>
                    <td width="5%">:</td>
                    <td><?php echo htmlspecialchars($result['name']); ?></td>
                </tr>
                <tr>
                    <td>Phone</td>
                    <td>:</td>
                    <td><?php echo htmlspecialchars($result['phone']); ?></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td>:</td>
                    <td><?php echo htmlspecialchars($result['email']); ?></td>
                </tr>
                <tr>
                    <td>Town Address</td>
                    <td>:</td>
                    <td><?php echo htmlspecialchars($result['address']); ?></td>
                </tr>
                <tr>
                    <td>County</td>
                    <td>:</td>
                    <td><?php echo htmlspecialchars($result['country']); ?></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td><a href="editprofile.php">Update Details</a></td>
                </tr>
            </table>
            <?php 
                }
            }
            ?>
        </div>
    </div>
</div>
<?php include 'footer.php';?>
