<?php include 'user-header.php'; ?>
<div class="main">
    <div class="content">
        <div class="section group">
            <div class="payment1">
                <h2>Complete the order by calling the number below the product</h2>
                 <a href="shop.php">back to buy</a>
                <a href="catshopname.php"> All shops</a> 
            </div>
            <div class="back">
            </div>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>
<style>
.payment1 {
    width: 90%;
    max-width: 400px;
    min-height: 30px;
    text-align: center;
    border: 1px solid blue;
    margin: 0 auto;
    padding: 30px;
}    
.payment1 h2 {
    border-bottom: 3px solid orange;
    margin-bottom: 20px;
    padding-bottom: 10px;
}
.payment1 a {
    background: black;
    border-radius: 30px;
    color: #fff;
    font-size: 14px;
    padding: 5px 30px;
    text-decoration: none; /* Added for better styling */
}
@media (max-width: 600px) {
    .payment1 {
        padding: 20px;
    }
    .payment1 h2 {
        font-size: 18px;
    }
    .payment1 a {
        font-size: 12px;
        padding: 5px 20px;
    }
}
</style>
