<?php

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

ob_start();
include_once 'Database.php';
include_once 'Formate.php';

class Session {
    
    // Start the session
    public static function init() {
        if (session_status() == PHP_SESSION_NONE) {
          
        }
    }

    // Set session variables
    public static function set($key, $value) {
        $_SESSION[$key] = $value;
    }

    // Get session variables
    public static function get($key) {
        return isset($_SESSION[$key]) ? $_SESSION[$key] : null;
    }

    // Check if a session variable is set
    public static function check($key) {
        return isset($_SESSION[$key]);
    }

    // Unset session variable
    public static function unset($key) {
        if (isset($_SESSION[$key])) {
            unset($_SESSION[$key]);
        }
    }

    // Destroy the session
    public static function destroy() {
        session_destroy();
        session_unset();
    }
}

class customer {
    
    private $db;
    private $fm;

    public function __construct() {
        $this->db = new Database();
        $this->fm = new Format();
    }

    public function customerRegistration($data) {
        // Check if array keys exist before accessing them
        $name = isset($data['name']) ? mysqli_real_escape_string($this->db->link, $data['name']) : '';
        $address = isset($data['address']) ? mysqli_real_escape_string($this->db->link, $data['address']) : '';
        $country = isset($data['country']) ? mysqli_real_escape_string($this->db->link, $data['country']) : '';
        $phone = isset($data['phone']) ? mysqli_real_escape_string($this->db->link, $data['phone']) : '';
        $email = isset($data['email']) ? mysqli_real_escape_string($this->db->link, $data['email']) : '';
        $pass = isset($data['pass']) ? mysqli_real_escape_string($this->db->link, md5($data['pass'])) : '';

        // Check for empty fields
        if (empty($name) || empty($address) || empty($country) || empty($phone) || empty($email) || empty($pass)) {
            $msg = "<span class='error' style='color: red;'>Fields must not be empty !</span>";
            return $msg;
        }

        // Check if email already exists
        $mailquery = "SELECT * FROM tbl_customer WHERE email = '$email' LIMIT 1";
        $mailchk = $this->db->select($mailquery);
        if ($mailchk != false) {
            $msg = "<span class='error' style='color: red;'>Email already exists !</span>";
            return $msg;
        } else {
            // Insert new customer data
            $query = "INSERT INTO tbl_customer(name, address, country, phone, email, pass) 
                      VALUES('$name', '$address', '$country', '$phone', '$email', '$pass')";
            $inserted_row = $this->db->insert($query);
            if ($inserted_row) {
                $msg = "<span class='success' style='color: red;'>Account created Successfully.</span>";
                return $msg;
            } else {
                $msg = "<span class='error' style='color: red;'>Customer Data Not inserted.</span>";
                return $msg;
            }
        }
    }

    public function customerLogin($data) {
        $email = isset($data['email']) ? mysqli_real_escape_string($this->db->link, $data['email']) : '';
        $pass = isset($data['pass']) ? mysqli_real_escape_string($this->db->link, md5($data['pass'])) : '';

        if (empty($email) || empty($pass)) {
            $msg = "<span class='error' style='color: red;'>Fields must not be empty !</span>";
            return $msg;
        }

        // Debugging output to check input values
        error_log("Email: $email, Password: $pass");

        $query = "SELECT * FROM tbl_customer WHERE email = '$email' AND pass = '$pass'";
        $result = $this->db->select($query);

        // Debugging output to check if query executes correctly
        if ($result === false) {
            error_log("Query Error: " . $this->db->link->error);
        } else {
            error_log("Query Success: " . $query);
        }

        if ($result != false) {
            $value = $result->fetch_assoc();
            Session::init();
            Session::set("cuslogin", true);
            Session::set("cmrId", $value['id']);
            Session::set("cmrName", $value['name']);
            
            // Output success message
            echo "<span class='success' style='color: red;'>Login successful!...</span>";
            
            // Redirect to index.php after a delay to show the success message
            header("refresh:1;url=shop.php");
            exit(); // Add exit to ensure the script stops executing after header redirect
        } else {
            $msg = "<span class='error' style='color: red;'>Email or Password not matched !</span>";
            return $msg;
        }
    }

    public function getCustomerData($id) {
        $query = "SELECT * FROM tbl_customer WHERE id = '$id'";
        $result = $this->db->select($query);
        return $result;
    }

    public function customerUpdate($data, $cmrId) {
        $name = isset($data['name']) ? mysqli_real_escape_string($this->db->link, $data['name']) : '';
        $address = isset($data['address']) ? mysqli_real_escape_string($this->db->link, $data['address']) : '';
        $country = isset($data['country']) ? mysqli_real_escape_string($this->db->link, $data['country']) : '';
        $phone = isset($data['phone']) ? mysqli_real_escape_string($this->db->link, $data['phone']) : '';
        $email = isset($data['email']) ? mysqli_real_escape_string($this->db->link, $data['email']) : '';

        if (empty($name) || empty($address) || empty($country) || empty($phone) || empty($email)) {
            $msg = "<span class='error' style='color: red;'>Fields must not be empty !</span>";
            return $msg;
        } else {
            $query = "UPDATE tbl_customer
                      SET name = '$name',
                          address = '$address', 
                          country = '$country', 
                          phone = '$phone', 
                          email = '$email' 
                      WHERE id = '$cmrId'";

            $updated_row = $this->db->update($query);
            if ($updated_row) {
                $msg = "<span class='success' style='color: red;'>Profile updated Successfully.</span>";
                return $msg;
            } else {
                $msg = "<span class='error' style='color: red;'>Customer Data Not Updated !</span>";
                return $msg;
            }
        }
    }
}
ob_end_flush();
?>
