<?php
// callback.php

// Ensure PHP error reporting is enabled for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Read the M-Pesa response
$mpesaResponse = file_get_contents('php://input');

// Log the M-Pesa response for debugging
$logFile = 'mpesaResponse.log';
$log = fopen($logFile, 'a');
fwrite($log, date("Y-m-d H:i:s") . " - " . $mpesaResponse . "\n");
fclose($log);

// Decode the JSON response
$response = json_decode($mpesaResponse, true);

if (!$response) {
    // If decoding fails, log an error and exit
    error_log("Failed to decode JSON response: " . $mpesaResponse);
    exit();
}

// Process the response
if (isset($response['Body']['stkCallback']['ResultCode'])) {
    if ($response['Body']['stkCallback']['ResultCode'] == 0) {
        // Payment successful
        $metadata = $response['Body']['stkCallback']['CallbackMetadata']['Item'];
        $transactionId = null;
        $amountPaid = null;
        $phoneNumber = null;

        foreach ($metadata as $item) {
            if ($item['Name'] == 'MpesaReceiptNumber') {
                $transactionId = $item['Value'];
            }
            if ($item['Name'] == 'Amount') {
                $amountPaid = $item['Value'];
            }
            if ($item['Name'] == 'PhoneNumber') {
                $phoneNumber = $item['Value'];
            }
        }

        // Example: Update your order status in the database here
        // $orderId = // Extract or match with your order ID logic
        // updateOrderStatus($orderId, 'Paid', $transactionId, $amountPaid, $phoneNumber);

        // For demonstration:
        file_put_contents("order_status.txt", "Order Paid: ID=$transactionId, Amount=$amountPaid, Phone=$phoneNumber\n", FILE_APPEND);
    } else {
        // Payment failed
        $resultCode = $response['Body']['stkCallback']['ResultCode'];
        $resultDesc = $response['Body']['stkCallback']['ResultDesc'];
        error_log("Payment failed: $resultDesc (Code: $resultCode)");
    }
} else {
    // Log error if response does not have expected structure
    error_log("Unexpected response structure: " . $mpesaResponse);
}
?>
