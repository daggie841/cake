<?php
ob_start();

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'admin-header.php'; 
include_once 'config.php';

// Function to fetch categories from the database
function getCategory($conn) {
    $stmt = $conn->prepare("SELECT catId, catName FROM tbl_category");
    if ($stmt === false) {
        echo "Error preparing statement: " . $conn->error;
        return null;
    }

    if (!$stmt->execute()) {
        echo "ERROR: Could not execute query: " . $stmt->error;
        $stmt->close();
        return null;
    }

    $result = $stmt->get_result();
    $categories = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $categories;
}

// Function to fetch shop names from the database
function getShopNames($conn) {
    $stmt = $conn->prepare("SELECT admin_id, shopname FROM adminlogin");
    if ($stmt === false) {
        echo "Error preparing statement: " . $conn->error;
        return null;
    }

    if (!$stmt->execute()) {
        echo "ERROR: Could not execute query: " . $stmt->error;
        $stmt->close();
        return null;
    }

    $result = $stmt->get_result();
    $shops = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $shops;
}

// Function to fetch category name by ID
function getCategoryNameById($catId, $conn) {
    $stmt = $conn->prepare("SELECT catName FROM tbl_category WHERE catId = ?");
    if ($stmt === false) {
        echo "Error preparing statement: " . $conn->error;
        return null;
    }

    $stmt->bind_param("i", $catId);
    if (!$stmt->execute()) {
        echo "ERROR: Could not execute query: " . $stmt->error;
        $stmt->close();
        return null;
    }

    $result = $stmt->get_result();
    $category = $result->fetch_assoc();
    $stmt->close();
    return $category['catName'] ?? null;
}

// Function to fetch shop name by ID
function getShopNameById($admin_id, $conn) {
    $stmt = $conn->prepare("SELECT shopname FROM adminlogin WHERE admin_id = ?");
    if ($stmt === false) {
        echo "Error preparing statement: " . $conn->error;
        return null;
    }

    $stmt->bind_param("i", $admin_id);
    if (!$stmt->execute()) {
        echo "ERROR: Could not execute query: " . $stmt->error;
        $stmt->close();
        return null;
    }

    $result = $stmt->get_result();
    $shop = $result->fetch_assoc();
    $stmt->close();
    return $shop['shopname'] ?? null;
}

// Function to fetch product details by ID
function getProductById($productId, $conn) {
    $stmt = $conn->prepare("SELECT * FROM tbl_product WHERE productId = ?");
    if ($stmt === false) {
        echo "Error preparing statement: " . $conn->error;
        return null;
    }

    $stmt->bind_param("i", $productId);
    if (!$stmt->execute()) {
        echo "ERROR: Could not execute query: " . $stmt->error;
        $stmt->close();
        return null;
    }

    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();
        $stmt->close();
        return $product;
    }

    $stmt->close();
    return null;
}

// Function to update product
function updateProduct($productId, $productName, $catId, $catName, $body, $price, $image, $phone, $admin_id, $shopname, $conn) {
    $stmt = $conn->prepare("UPDATE tbl_product SET productName = ?, catId = ?, catName = ?, body = ?, price = ?, image = ?, phone = ?, admin_id = ?, shopname = ? WHERE productId = ?");
    if ($stmt === false) {
        echo "Error preparing statement: " . $conn->error;
        return false;
    }

    $stmt->bind_param("sissdsiisi", $productName, $catId, $catName, $body, $price, $image, $phone, $admin_id, $shopname, $productId);
    if (!$stmt->execute()) {
        echo "ERROR: Could not execute query: " . $stmt->error;
        $stmt->close();
        return false;
    }

    $stmt->close();
    return true;
}

// Fetch categories and shop names
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$categories = getCategory($conn);
$shops = getShopNames($conn);
if ($categories === null || $shops === null) {
    echo "Error fetching categories or shops.";
}

// Handle form submission
if (isset($_POST['submit'])) {
    $productId = $_POST['productId'] ?? null;
    $productName = $_POST['productName'] ?? '';
    $catId = $_POST['catId'] ?? null;
    $body = $_POST['body'] ?? '';
    $price = $_POST['price'] ?? 0;
    $phone = $_POST['phone'] ?? '';
    $admin_id = $_POST['admin_id'] ?? null;

    // Validate phone number
    if (!preg_match('/^\d{10}$/', $phone)) {
        echo "Invalid phone number. Please enter exactly 10 digits.";
        $conn->close();
        exit();
    }

    // Handle image upload
    $image = $_POST['currentImage'] ?? null; // Keep existing image if no new one is uploaded
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $image_dir = 'image/';
        $image_name = basename($_FILES['image']['name']);
        $image_path = $image_dir . $image_name;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $image_path)) {
            $image = $image_name;
        } else {
            echo "Error moving uploaded file.";
        }
    }

    // Fetch catName based on catId
    if ($catId) {
        $catName = getCategoryNameById($catId, $conn);
        if ($catName === null) {
            echo "Error: Category not found.";
            $conn->close();
            exit();
        }
    } else {
        echo "Please select a category.";
        $conn->close();
        exit();
    }

    // Fetch shopname based on admin_id
    if ($admin_id) {
        $shopname = getShopNameById($admin_id, $conn);
        if ($shopname === null) {
            echo "Error: Shop name not found.";
            $conn->close();
            exit();
        }
    } else {
        echo "Please select a shop name.";
        $conn->close();
        exit();
    }

    // Update product
    if (updateProduct($productId, $productName, $catId, $catName, $body, $price, $image, $phone, $admin_id, $shopname, $conn)) {
        header("Location: productlist.php?productId=$productId");
        exit();
    } else {
        echo "Error updating product.";
    }

    $conn->close();
    exit();
}

// Fetch product details if editing
$productId = $_GET['proid'] ?? null;
if ($productId) {
    $product = getProductById($productId, $conn);
    if ($product === null) {
        echo "Error: Product not found.";
        $conn->close();
        exit();
    }
} else {
    echo "Error: No product ID provided.";
    $conn->close();
    exit();
}
ob_end_flush();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            margin-bottom: 20px;
            font-size: 24px;
            color: #333;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group input[type="file"],
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form-group textarea {
            resize: vertical;
            height: 100px;
        }
        .form-group img {
            margin-top: 10px;
        }
        .form-group p {
            margin: 5px 0 0;
        }
        input[type="submit"] {
            background-color: #5cb85c;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        input[type="submit"]:hover {
            background-color: #4cae4c;
        }
        .ic-dashboard {
            list-style-type: none;
            padding: 0;
            margin-top: 20px;
        }
        .ic-dashboard li {
            display: inline;
            margin-right: 10px;
        }
        .ic-dashboard a {
            text-decoration: none;
            color: #337ab7;
        }
        .ic-dashboard a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Product</h2>
        <form action="productedit.php?proid=<?= htmlspecialchars($productId) ?>" method="post" enctype="multipart/form-data">
            <input type="hidden" name="productId" value="<?= htmlspecialchars($product['productId']) ?>">
            <div class="form-group">
                <label for="productName">Product Name:</label>
                <input type="text" id="productName" name="productName" value="<?= htmlspecialchars($product['productName']) ?>" required>
            </div>
            <div class="form-group">
                <label for="body">Description:</label>
                <textarea id="body" name="body" required><?= htmlspecialchars($product['body']) ?></textarea>
            </div>
            <div class="form-group">
                <label for="price">Price:</label>
                <input type="number" id="price" name="price" value="<?= htmlspecialchars($product['price']) ?>" required>
            </div>
            <div class="form-group">
                <label for="image">Image:</label>
                <input type="file" id="image" name="image" accept="image/*">
                <input type="hidden" name="currentImage" value="<?= htmlspecialchars($product['image']) ?>">
                <?php if ($product['image']): ?>
                    <p>Current image: <img src="image/<?= htmlspecialchars($product['image']) ?>" alt="Product Image" width="100"></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="categorySelect">Item Category:</label>
                <select id="categorySelect" name="catId" required>
                    <option value="">Select a category</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= htmlspecialchars($category['catId']) ?>" <?= $category['catId'] == $product['catId'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($category['catName']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="shopSelect">Select Shop:</label>
                <select id="shopSelect" name="admin_id" required>
                    <option value="">Select a shop</option>
                    <?php foreach ($shops as $shop): ?>
                        <option value="<?= htmlspecialchars($shop['admin_id']) ?>" <?= $shop['admin_id'] == $product['admin_id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($shop['shopname']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="phone">Phone Number:</label>
                <input type="text" id="phone" name="phone" value="<?= htmlspecialchars($product['phone']) ?>" required>
            </div>
            <input type="submit" name="submit" value="Update Product">
        </form>
        <ul class="ic-dashboard">
            <li><a href="productlist.php">Back to Product List</a></li>
        </ul>
    </div>
</body>
</html>
