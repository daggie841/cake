<?php include 'admin-header.php'; ?>
<?php include 'Database.php'; ?>
<?php include 'Formate.php'; ?>


<?php
if (!isset($_GET['msgid']) || $_GET['msgid'] == NULL) {
   
   echo "<script>window.location='message.php';</script>";
   
} else {

    $id = $_GET['msgid'];
}


 ?>


        <div class="grid_10">
        
            <div class="box round first grid">
                <h2>View Message</h2>
<?php 
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

  echo "<script>window.location='message.php';</script>"; 

}

?>


                <div class="block">               
                 <form action="" method="post" >

             <?php
            $db = new Database();
            $fm = new Format();
            $query = "select * from tbl_contact where id='$id'";
            $msg = $db->select($query);
            if ($msg) {

            while ($result = $msg->fetch_assoc()) {


           ?>
                    <table class="form">
                       
                <tr>
                    <td>
                        <label>Name</label>
                    </td>
                    <td>
                        <input type="text" readonly value="<?php echo $result['name'];?>" class="medium" />
                    </td>
                </tr>

                        <tr>
                            <td>
                                <label>Email</label>
                            </td>
                            <td>
                                <input type="text" readonly value="<?php echo $result['email'];?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Phone</label>
                            </td>
                            <td>
                                <input type="text" readonly value="<?php echo $result['contact'];?>" class="medium" />
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label>Date</label>
                            </td>
                            <td>
                                <input type="text" readonly value="<?php echo $fm->formatDate($result['date']);?>" class="medium" />
                            </td>
                        </tr>
                     
                    
                   
                    
                       
                    
                        <tr>
                            <td>
                                <label>Message</label>
                            </td>
                            <td>
                                <textarea class="tinymce" name="message">
                                    <?php echo $result['message'];?>

                                </textarea>
                            </td>
                        </tr>

                       
                        

                        <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Ok" />
                            </td>
                        </tr>
                    </table>

                    <?php } } ?>

                    </form>
                </div>
            </div>
        </div>

<style>body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.grid_10 {
    width: 100%;
    margin: 0px auto;
    padding: 0px;
}

.box {
    background-color: #fff;
    border: 1px solid #ddd;
    padding: 0px;
    border-radius: 5px;
}

.round {
    border-radius: 10px;
}



h2 {
    color: #333;
    margin-bottom: 0px;
}

.block {
    padding: 10px;
}

table.form {
    width: 100%;
}

table.form td {
    padding: 0px;
}

table.form input[type="text"], table.form textarea {
    width: 100%;
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 4px;
    box-sizing: border-box;
}

table.form input[type="submit"]
</style>




 <?php include 'adminfooter.php'; ?>



