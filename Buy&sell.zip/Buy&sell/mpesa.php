<?php

define('CONSUMER_KEY', '9i5Kw9PwUgXaJJSWPAeKywNb5cgbHAFHhhiGyBILJgCwU2lv');
define('CONSUMER_SECRET', 'tHG6v7AmnGaG1JHYNZhtSrs8kt50oDZq1GPDAyPy94DbIZC7fHjrFGscybGMVDTE');
define('SHORTCODE', '174379');
define('PASSKEY', 'bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919');
define('CALLBACK_URL', 'https://cleanwavess.com/callback.php');

// Function to get access token
if (!function_exists('getAccessToken')) {
    function getAccessToken() {
        $url = 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';
        $credentials = base64_encode(CONSUMER_KEY . ':' . CONSUMER_SECRET);

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Authorization: Basic ' . $credentials));
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($curl);
        curl_close($curl);

        $result = json_decode($response);
        return $result->access_token;
    }
}
?>
