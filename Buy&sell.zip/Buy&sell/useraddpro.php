<?php include 'user-header.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mpeketoni Buy and Sell</title>
    <style>
        body {
            
    </style>
</head>
<body>
    <div class="content">
        <h1>Welcome to www.dukaletu.com</h1>
    </div>

    <div class="content">
        <div class="message">
            <p>Welcome to product Sell's and marketing.<br>
             Here we advertise your products to customers, by using this Online shop you can reach more customers using this platform.<br> In this platform we create a an online shop where all of your products will be posted in that online shop, after we have posted all product in your online store clients will be access your shop from all over the country and make orders through the phone call.
             <br>To become an authorized poster, you are needed to agree to our terms and conditions:</p>
            <ul>
                <li>1. You need to get a personal admin account.</li>
                <li>2. Pay 1000 KSH per 6 months.</li>
                <li>3. Images should be clear, else your account will be banned and no money refunded.</li>
                            </ul>
            <div class="terms">
                <input type="checkbox" id="terms" name="terms">
                <label for="terms">I accept and agree to the terms and conditions</label>
                <p>Am a member <a href="adminlogin.php">login</a></p>
                <p>I want to be a Member</p>
            </div>
        </div>
    </div>
</body>
</html>
<?php include 'footer.php';?>