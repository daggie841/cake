<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'user-header.php'; 
include 'Product.php'; 
include_once 'Formate.php';
include_once 'Category.php';
?>

<div class="main">
    <div class="content_top">
        <!-- Content Top -->
    </div>

    <div class="container">
        <button class="hamburger" onclick="toggleSidebar()">☰</button>
        <div class="sidebar">
           <h2>CATEGORIES</h2>
           <ul>
               <li><a href="shop.php">All</a></li>
               <?php 
               $ct = new Category();
               $getCat = $ct->getAllCat();
               if ($getCat) {
                   foreach ($getCat as $result) {
               ?>
                       <li><a href="productbycat.php?catId=<?php echo htmlspecialchars($result['catId']); ?>"><?php echo htmlspecialchars($result['catName']); ?></a></li>
               <?php 
                   }
               }
               ?>
           </ul>
        </div>


        


        <div class="product-grid">
            <?php
            $fm = new Format();
            $pd = new Product();
            
            $getpd = $pd->getAllProducts();
            if ($getpd && $getpd->num_rows > 0) {
                while ($result = $getpd->fetch_assoc()) { 
            ?>
            <div class="product-item">
                <div class="product-image-container">
                    <a href="details.php?proid=<?php echo htmlspecialchars($result['productId']); ?>">
                        <img src="<?php echo htmlspecialchars($result['image']); ?>" class="product-image" alt="<?php echo htmlspecialchars($result['productName']); ?>">
                    </a>
                </div>
                <div class="product-details">
                    <p><span style="color: black; font-weight: bold;"><?php echo htmlspecialchars($result['productName']); ?></span></p>
                        <div class="product-price">
                        <p>ksh. <?php echo htmlspecialchars($result['price']); ?></p>
                         </div> 
                    <div class="product-shop">
                        <p> <span><?php echo htmlspecialchars($result['shopname'] ?? 'N/A'); ?></span></p>
                        <p>Call: <span><?php echo htmlspecialchars($result['phone']); ?></span></p>
                    </div>
                    
                </div>
            </div>
            <?php 
                } 
            } else {
                echo "No products found.";
            }
            ?>
        </div>
    </div>
</div>

<style>
.container {
    align-items: flex-start;
    display: flex;
    flex-wrap: wrap;
    margin: 0;
}

.sidebar {
    flex: 1;
    max-width: 100px;
    padding: 20px;
    background: #f4f4f4;
    border-right: 1px solid #ddd;
}

.sidebar h2 {
    font-size: 10px;
    margin-top: 10;
}

.sidebar ul {
    list-style-type: none;
    padding: 0;
}

.sidebar ul li {
    margin: 10px 0;
}

.sidebar ul li a {
    text-decoration: none;
    color: #333;
}

.sidebar ul li a:hover {
    text-decoration: underline;
}

.product-grid {
    flex: 3;
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    justify-content: center;
    margin: 0;
    padding: 10px;
}

.product-item {
    border: 1px solid #ddd;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    overflow: hidden;
    width: 100PX;
    max-width: 400px;
    text-align: center;
    display: flex;
    flex-direction: column;
}

.product-image-container {
    width: 100%;
    margin-top: 0; /* Adjust this as needed */
}

.product-image {
    width: 100%;
    height: auto;
    object-fit: contain;
}

.product-details {
    padding: 0px;
    flex-grow: 1; /* Ensures the content takes up remaining space */
}

.product-price {
     margin-top: 0.5cm; /* Space between product details and price/shop */
    margin-bottom: 0;
    color: ;
    font-weight: bold;
    font-size: 12px;
/*    margin-bottom: 5px;*/
}

.product-shop {
     margin-top: 0.5cm; /* Space between product details and price/shop */
    margin-bottom: 0;
    color: black;
    font-weight: bold;
    font-size: 12px;
/*    margin-bottom: 5px;*/
}

.button {
    display: inline-block;
    padding: 8px 12px;
    font-size: 14px;
    font-weight: bold;
    color: white;
    background: orange;
    border-radius: 5px;
    text-decoration: none;
}

.button a.details {
    text-decoration: none;
    color: white;
}

.button:hover {
    background: darkorange;
}

.hamburger {
    display: none;
    font-size: 20px;
    padding: 10px;
    cursor: pointer;
    background: white;
    border: none;
    outline: none;
}

@media screen and (max-width: 600px) {
    .container {
        flex-direction: column;
    }

    .sidebar {
        display: none;
        max-width: none;
    }

    .product-item {
        max-height: 50vh; /* Ensure product item fits screen height */
        width: calc(45% - 0px); /* Adjust as needed */
    }

    .hamburger {
        align-content: flex-end;
        display: block;
    }
}

@media screen and (max-width: 990px) {
    .product-item {
        width: calc(40% - 0px);
    }
}

@media screen and (min-width: 1200px) {
    .product-item {
        width: calc(10.33% - 0px);
    }
}

    }
</style>

<script>
    function toggleSidebar() {
        var sidebar = document.querySelector('.sidebar');
        sidebar.style.display = (sidebar.style.display === 'block') ? 'none' : 'block';
    }
</script>

<?php include 'footer.php'; ?>
