<?php include 'user-header.php';?>





<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sikam about</title>
</head>
<body>
  <header>
    <h1><b>Sikam chicken Farm</b></h1>
  </header>
  
    <p>Sikam chicken Farms was established in 2024, This Poultry Farm embodies a vision of supporting small farmers by providing them with a reliable place where they can get their poultry products. Our mission is to streamline the poultry market challenges by offering a diverse range of poultry chickens, catering to various needs from<b> Hatching eggs,1-day-old chicks to mature cocks, hens, broilers, layers, and even improved kienyeji chickens.</b></p>

    <p> Sikam Chicken Farm, we pride ourselves on being a one-stop destination for all Chicken-related needs. Our commitment goes beyond mere convenience; we prioritize delivering pure, high-quality products to our clients. With stringent quality control measures in place, customers can trust that every purchase from Sikam farm meets the highest standards.</p>

    <p>By bridging the gap between small farmers and consumers, we not only provide a marketplace but also foster a community dedicated to sustainable poultry farming practices. Sikam  Farm stands as a testament to our dedication to supporting local agriculture while ensuring access to superior poultry products for all our valued customers.</p>
  </div>
     <style>
header {
   font-family: "Times New Roman", Times, serif;
  margin-right: 50px;
  margin-left: 50px;
  padding: 0;
  padding: 20px;
  text-align: center;
}

h1 {
  font-size: 36px;
  font-weight: bold;
}

p {
  font-size: 18px;
  line-height: 1.5;
  color: #333; <-- Change paragraph text color as needed -->
  margin: 0px;
}

</style>
  <script src="script.js"></script>
</body>
</html>
<?php include 'footer.php';?>