<?php
ob_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Database connection
            include 'config.php';
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        // Your database operations here
    } catch (Exception $e) {
        // Handle database connection errors
        echo "Connection failed: " . $e->getMessage();
    }
}

// Handle logout action
if (isset($_GET['action']) && $_GET['action'] == 'logout') {
    session_destroy(); // Destroy the session
    header('Location: adminlogin.php'); // Redirect to the login page
    exit(); // Ensure script termination after redirection
}
ob_end_flush();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <style>
        /* CSS styles */
        body {
            font-family: 'Times New Roman', Times, serif;
            margin: 0;
            padding: 0;
        }
        .header {
            font-family: 'Times New Roman', Times, serif;
            background-color: skyblue;
            color: #fff;
            padding: 10px 20px;
            overflow: hidden;
            display: flex; /* Use flexbox */
            align-items: center; /* Center vertically */
        }
        .floatright {
            margin-left: auto; /* Push to the right */
        }
        .floatleft img {
            margin-right: 100px; /* Adjust spacing between images */
        }
        .nav {
            list-style: none;
            padding: 0;
            margin: 0;
            background-color: orange;
            overflow: hidden;
        }
        .nav li {
            width: 40;
            float: left;
        }
        .nav li a {
            display: block;
            color: white;
            text-align: center;
            padding: 4px 20px;
            text-decoration: none;
        }
        .nav li a:hover {
            background-color: blue;
        }
        .inline-ul {
            padding: 0;
            margin: 0;
            list-style-type: none;
        }
        .inline-ul li {
            display: inline;
            margin-right: 10px;
        }

    </style>
</head>
<body>
    <div class="header">
        <div>
            <h1>Mpeketoni Buy&sell</h1>
        </div>
        <div class="floatright">
            <div class="floatleft">
               
            </div>
            <div class="floatleft marginleft10">
                <ul class="inline-ul">
                 
                    <li><a href="?action=logout">Logout</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="grid_12">
        <ul class="nav main">
            <li class="ic-dashboard"><a href="admin_dashboard.php"><span>Dashboard</span></a></li>
             <li class="ic-grid-tables"><a href="create_admin.php"><span>New admin</span></a></li>
            <li class="ic-typography"><a href="changepassword.php"><span>Change Password</span></a></li>
            <li class="ic-grid-tables"><a href="inbox.php"><span>Orders</span></a></li>
            <li class="ic-charts"><a href="index.php" target="_blank"><span>Visit Website</span></a></li>
        </ul>
    </div>
</body>
</html>
