<?php 
include 'user-header.php'; 
include_once 'Cart.php'; 
include_once 'Formate.php'; 

// Include necessary files and instantiate objects
$ct = new Cart();
$fm = new Format();

// Check if customerId is set in the GET request and handle the confirmation
if (isset($_GET['customerId'])) {
    $id = $_GET['customerId'];
    $confirm = $ct->productShiftConfirm($id);
}

// Check if Customer ID is set in session, if not, set it
if (!isset($_SESSION['cmrId'])) {
    // You might set it here based on your application logic, for example:
    // $_SESSION['cmrId'] = $someValue;
    // For demonstration purpose, let's set it to a default value
    $_SESSION['cmrId'] = "DefaultCustomerID"; 
}
?>

<style>
    .tblone tr td {
        text-align: justify;
    }
</style>

<div class="main">
    <div class="content">
        <div class="section group">
            <div class="order">
                <h2>Your Ordered Details</h2>
                <table class="tblone">
                    <tr>
                        <th>No</th>
                        <th>Product Name</th>
                        <th>Image</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <!--<th>Date</th>-->
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                    <?php
                    // Retrieve customer ID from session
                    $cmrId = $_SESSION['cmrId'];
                    $getOrder = $ct->getOrderedProduct($cmrId);

                    if ($getOrder) {
                        $i = 0;
                        while ($result = $getOrder->fetch_assoc()) {
                            $i++;
                    ?>
                            <tr>
                                <td><?php echo $i; ?></td>
                                <td><?php echo $result['productName']; ?></td>
                                 <td><img src="<?php echo htmlspecialchars($result['image']); ?>" style="width: 40%;" /></td>
                                <td><?php echo $result['quantity']; ?></td>
                                <td>ksh. <?php echo $result['price']; ?></td>
                              
                                <td>
                                    <?php
                                    if ($result['status'] == '0') {
                                        echo "Pending order";
                                    } elseif ($result['status'] == '1') {
                                        echo "Delivery in process";
                                    } else {
                                        echo "Successfully delivered";
                                    }
                                    ?>
                                </td>
                                <?php
                                if ($result['status'] == '1') { ?>
                                    <td><a href="?customerId=<?php echo $result['id']; ?>">Confirm</a></td>
                                <?php } elseif ($result['status'] == '2') { ?>
                                    <td>Ok</td>
                                <?php } elseif ($result['status'] == '0') { ?>
                                    <td>Not received</td>
                                <?php } ?>
                            </tr>
                    <?php
                        }
                    }
                    ?>
                </table>
            </div>
        </div>
        <div class="clear"></div>
    </div>
</div>

<?php include 'footer.php'; ?>

<style>
    .tblone {
        width: 100%%;
        border-collapse: collapse;
        margin-bottom: 20px;
    }

    .tblone th,
    .tblone td {
        padding: 5px;
        border: 1px solid #ddd;
        text-align: center;
    }

    .tblone th {
        background-color: #f2f2f2;
    }

    .order {
        margin-bottom: 20px;
    }

    @media only screen and (max-width: 500px) {
        .tblone {
             width: 100%;
            font-size: 8px;
        }
    }
</style>
