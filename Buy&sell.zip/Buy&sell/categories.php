<?php include 'user-header.php';?>
<?php include 'Category.php';?>

<?php
if (isset($_GET['proid'])) {
    $id = preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['proid']);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    $quantity = $_POST['quantity'];
    // Assuming $ct is an instance of a class with addToCart() method
    $addCart = $ct->addToCart($quantity, $id);
}

?> 

<style>
    .mybutton {width: 100px;float: left;margin-right: 50px;}
</style>

<div class="main">
    <div class="content">
        <div class="section group">
            <div class="cont-desc span_1_of_">      
                <div class="grid images_3_of_">
                    <!-- <img src="13.jpg" width="400"> -->
                </div>

                <div class="rightsidebar span_3_of_1">
                    <h2>CATEGORIES</h2>
                    <ul>
                        <?php 
                        $ct = new Category();
                     
                        $getCat = $ct->getAllCat();
                        if ($getCat) {
                            // Fetch associative array from the result set
                            foreach ($getCat as $result) {
                        ?>
                                <li><a href="productbycat.php?catId=<?php echo $result['catId']; ?>"><?php echo $result['catName']; ?></a></li>
                        <?php 
                            }
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php';?>


<style>
    .grid {
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .images_3_of_ img {
        max-width: 100%; /* Ensures the image doesn't overflow its container */
    }

    .rightsidebar {
        margin-top: 20px;
    }

    /* Adjustments for larger screens */
    @media only screen and (min-width: 768px) {
        .section.group {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .cont-desc {
            display: flex;
            flex-direction: row;
            align-items: flex-start;
        }

        .grid {
            margin-right: 20px; /* Space between image and category list */
        }
    }
</style>
