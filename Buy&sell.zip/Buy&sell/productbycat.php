<?php
include 'user-header.php'; 
include_once 'Product.php'; 
include_once 'Category.php';

if (!isset($_GET['catId']) || $_GET['catId'] == NULL) {
    echo "<script>window.location='404.php';</script>";
} else {
    $id = preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['catId']);
}
?>

<div class="main">
    <div class="content">
        <div class="content_top">
            <div class="clear"></div>
        </div>
        <div class="container">
            <button class="hamburger" onclick="toggleSidebar()">☰</button>
            <div class="sidebar" id="sidebar">
                <ul>
                    <li><a href="shop.php">All</a></li>
                    <?php 
                    $ct = new Category();
                    $getCat = $ct->getAllCat();
                    if ($getCat) {
                        foreach ($getCat as $result) {
                    ?>
                        <li><a href="productbycat.php?catId=<?php echo htmlspecialchars($result['catId']); ?>"><?php echo htmlspecialchars($result['catName']); ?></a></li>
                    <?php 
                        }
                    }
                    ?>
                </ul>
            </div>
            <div class="product-grid">
                <?php 
                $fm = new Format();
                $pd = new Product();
                $productbycat = $pd->productByCat($id);
                if ($productbycat) {
                    while ($result = $productbycat->fetch_assoc()) {
                ?>
                    <div class="product-item">
                        <a href="details.php?proid=<?php echo htmlspecialchars($result['productId']); ?>">
                            <img src="<?php echo htmlspecialchars($result['image']); ?>" alt="<?php echo htmlspecialchars($result['productName']); ?>" class="product-image" />
                        </a>
                        <div class="product-details">
                            <p><span style="color: red; font-weight: bold;"><?php echo htmlspecialchars($result['productName']); ?></span></p>
                            <div class="product-price">
                                <p>ksh. <?php echo htmlspecialchars($result['price']); ?></p>
                            </div> 
                            <div class="product-shop">
                                <p><span><?php echo htmlspecialchars($result['shopname'] ?? 'N/A'); ?></span></p>
                                <p>Call: <span><?php echo htmlspecialchars($result['phone']); ?></span></p>
                            </div>
                        </div>
                    </div>
                <?php 
                    }
                } else {
                    echo "<span style='color: red;'>Product you are looking for is NOT found. Back to shop...</span>";
                    echo "<script>
                            setTimeout(function(){
                                window.location.href = 'shop.php';
                            }, 1000);
                          </script>";
                }
                ?>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
}

.container {
    align-items: flex-start;
    display: flex;
    flex-wrap: wrap;
    margin: 0;
}

.sidebar {
    flex: 1;
    max-width: 100px;
    padding: 20px;
    background: #f4f4f4;
    border-right: 1px solid #ddd;
}

.sidebar ul {
    list-style-type: none;
    padding: 0;
}

.sidebar ul li {
    margin: 10px 0;
}

.sidebar ul li a {
    text-decoration: none;
    color: #333;
}

.sidebar ul li a:hover {
    text-decoration: underline;
}

.product-grid {
    flex: 3;
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    justify-content: center;
    margin: 10px;
    padding: 10px;
}

.product-item {
    border: 1px solid #ddd;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    overflow: hidden;
    width: 100%;
    max-width: 300px;
    text-align: center;
    display: flex;
    flex-direction: column;
}

.product-image {
    width: 100%;
    height: auto;
    object-fit: contain;
}

.product-price {
    margin-top: 0.5cm;
    margin-bottom: 0;
    color: green;
    font-weight: bold;
    font-size: 12px;
}

.product-shop {
    margin-top: 0.5cm;
    margin-bottom: 0;
    color: black;
    font-weight: bold;
    font-size: 12px;
}

.button {
    display: block;
    padding: 3px 7px;
    font-size: 14px;
    font-weight: bold;
    color: white;
    background: orange;
    border-radius: 5px;
    text-decoration: none;
}

.button:hover {
    background: darkorange;
}

.hamburger {
    display: none;
    font-size: 20px;
    padding: 10px;
    cursor: pointer;
    background: white;
    border: none;
    outline: none;
}

@media screen and (max-width: 767px) {
    .container {
        flex-direction: column;
    }

    .sidebar {
        display: none;
        max-width: none;
    }

    .product-item {
        max-height: 50vh;
        width: calc(45% - 0px);
    }

    .hamburger {
        display: block;
    }
}

@media screen and (min-width: 768px) and (max-width: 1199px) {
    .product-item {
        width: calc(20% - 0px);
    }
}

@media screen and (min-width: 1200px) {
    .product-item {
        width: calc(10.33% - 0px);
    }
}
</style>

<script>
function toggleSidebar() {
    var sidebar = document.querySelector('.sidebar');
    sidebar.style.display = (sidebar.style.display === 'block') ? 'none' : 'block';
}
</script>
