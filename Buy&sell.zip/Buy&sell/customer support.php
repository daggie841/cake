<?php include 'user-header.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
 
  <title>sikam Farm</title>
</head>
<body>
  <header>
    <h1><b>SIKAM FARMS</b></h1></h1>
  </header>
  
    <h2><b>Product & Services we offer!</b></p>
<h3>1.Hatching Eggs</h3>
<p>We offer fertile and high-quality improved Kienyeji hatching eggs with a high hatch rate, ensuring you receive the best potential for your poultry farming.</p>

<h3>2.Hatching Services</h3>
<p>Bring us your eggs, and we'll return them to you as healthy chicks. We specialize in hatching fresh eggs that are seven (7) days old or younger. Incubation day is every Friday, and chicks must be picked up within 48 hours of hatching.</p>

<h3>3.Day-Old Chicks</h3>
<p>Our day-old chicks are healthy and come from well-managed, improved Kienyeji parent stock, ensuring strong and robust chicks for your farm.</p>

<h3>4.One-Week-Old Chicks</h3>
<p>Our one-week-old chicks are healthy and have received their first dose of the Newcastle Disease (NCD) vaccine. They come from our carefully selected parent stock, ensuring optimal health and growth.</p>

<h3>5.Two-Week-Old Chicks</h3>
<p>Our two-week-old chicks are healthy and have been administered the first dose of both the Newcastle Disease (NCD) and Gumboro vaccines. These chicks are nurtured from our high-quality parent stock.</p>

<h3>6.Three-Week-Old Chicks</h3>
<p>Our three-week-old chicks are healthy and have received the first and second doses of the Newcastle Disease (NCD) vaccine, along with the first dose of the Gumboro vaccine. They are bred from our superior parent stock for the best health outcomes.</p>

<h3>7.Four-Week-Old Chicks</h3>
<p>Our four-week-old chicks are healthy and have been given the first and second doses of both the Newcastle Disease (NCD) and Gumboro vaccines. They come from our high-quality parent stock, ready to thrive on your farm.</p>

<h3>8.Live Kienyeji Chicken</h3>
<p>Our live Kienyeji chickens are healthy and tasty, raised with care to ensure the best quality for your table.</p>

<h3>9.Dressed Kienyeji Chicken</h3>
<p>Our dressed Kienyeji chickens are healthy, tasty, and ready for your kitchen. We provide only the best quality poultry.</p>

<h3>10.Sikam Kienyeji Eggs</h3>
   <p>Our Sikam Kienyeji eggs are known for their healthy, deep orange yolks, produced by hens from Sikam farms. Enjoy the rich taste and nutritional benefits of these premium eggs.</p>
   <P4>We are happy to serve our customer quality service!</P4>
  </div>
  <style>
body {
   font-family: "Times New Roman", Times, serif;
  background-color: white; 
}

header {
  color:black;
  font-weight:bold;
  padding: 0px;
  text-align: center;
}

h1 {
  text-align: center;
  font-size: 36px;
  font-weight: bold;
}
h2 {
  text-align: center;
  font-size: 18px;
  font-weight: bold;
}

h3 {
  margin-left:40px;
  font-size: 20px;
  
}

p {
  font-size: 18px;
  margin-right:40px;
  margin-left:40px;
  line-height: 1.5;
  color: #333; <-- Change paragraph text color as needed -->
  margin: 0px;
}
p4 {
  text-align: center;
  font-size: 14px;
  font-weight: bold;
  color:red;
}

</style>


</body>
</html>
<?php include 'footer.php';?>