<?php include 'user-header.php'; ?>
<?php include 'Database.php'; ?>
<?php include 'Formate.php'; ?>

<?php
$db = new Database();
$fm = new Format();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $fm->validation($_POST['name']);
    $email = $fm->validation($_POST['email']);
    $contact = $fm->validation($_POST['contact']);
    $message = $fm->validation($_POST['message']);

    $link = $db->getLink();
    $name = mysqli_real_escape_string($link, $name);
    $email = mysqli_real_escape_string($link, $email);
    $contact = mysqli_real_escape_string($link, $contact);
    $message = mysqli_real_escape_string($link, $message);

    $error = "";

    if (empty($name)) {
        $error = "Name must not be empty!";
    } elseif (empty($email)) {
        $error = "Email must not be empty!";
    } elseif (empty($contact) || !preg_match('/^\d{10}$/', $contact)) {
        $error = "Contact field must contain 10 numbers";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid Email Address!";
    } elseif (empty($message)) {
        $error = "Message field must not be empty!";
    } else {
        $query = "INSERT INTO tbl_contact(name, email, contact, message) VALUES('$name', '$email', '$contact', '$message')";
        $inserted_rows = $db->insert($query);

        if ($inserted_rows) {
            $msg = "Message Sent Successfully.";
        } else {
            $error = "Message not sent!";
        }
    }
}

// Fetch existing links from the database
$query = "SELECT name, email, contact, message FROM tbl_contact";
$contacts = $db->select($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .main {
            width: 100%;
            margin: 10 auto;
        }
        .content {
            margin-top: 20px;
        }
        .support {
            margin-bottom: 20px;
        }
        .support_desc {
            float: left;
            width: 60%;
        }
        .support img {
            border-radius: 10px;
            float: right;
            image-resolution: 20px;
        }
        .clear {
            clear: both;
        }
        .section.group {
            display: flex;
        }
        .col {
            flex: 1;
        }
        .span_2_of_3 {
            margin-right: 20px;
        }
        .contact-form {
            background: #f4f4f4;
            padding: 0px;
            border-radius: 10px;
        }
        .contact-form h2 {
            margin-bottom: 20px;
        }
        .contact-form div {
            margin-bottom: 10px;
        }
        .contact-form label {
            display: block;
            margin-bottom: 5px;
        }
        .contact-form input[type="text"],
        .contact-form textarea {
            width: 80%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 30px;
        }
        .contact-form input[type="submit"] {
            background: orange;
            color: #fff;
            padding: 1px 20px;
            border: none;
            cursor: pointer;
            border-radius: 10px;
        }
        .contact-form input[type="submit"]:hover {
            background: #555;
        }
        .company_address {
            background: #e2e2e2;
            padding: 20px;
            border-radius: 10px;
        }
        .company_address p {
            margin: 0 0 10px;
        }
    </style>
</head>
<body>
<div class="main">
    <div class="content">
        <div class="support">
            <div class="support_desc">
                <h3>Live Support</h3>
                <p><span>24 hours | 7 days a week | 365 days a year &nbsp;&nbsp; Live Technical Support</span></p>
            </div>
            <img src="call.jpg" width="300" alt="Live Support"/>
            <div class="clear"></div>
        </div>
        <div class="section group">
            <div class="col span_2_of_3">
                <div class="contact-form">
                    <h2>Contact Us</h2>

                    <?php
                    if (isset($error)) {
                        echo "<span style='color:red'>$error</span>";
                    }

                    if (isset($msg)) {
                        echo "<span style='color:green'>$msg</span>";
                    }
                    ?>

                    <form action="" method="post">
                        <div>
                            <span><label>NAME</label></span>
                            <span><input type="text" name="name" value=""></span>
                        </div>
                        <div>
                            <span><label>E-MAIL</label></span>
                            <span><input type="text" name="email" value=""></span>
                        </div>
                        <div>
                            <span><label>MOBILE.NO</label></span>
                            <span><input type="text" name="contact" value=""></span>
                        </div>
                        <div>
                            <span><label>MESSAGE</label></span>
                            <span><textarea name="message"></textarea></span>
                        </div>
                        <div>
                            <span><input type="submit" name="submit" value="SUBMIT"></span>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col span_1_of_3">
                <div class="company_address">
                    <h2>Company Information :</h2>
                    <p>Nyanza region,</p>
                    <p>P.O Box 199,</p>
                    <p>Homabay</p>
                    <p>Mobile: 076846612</p>
                    <p>Phone: 0115403451</p>
                    <p>Email: <span>Douglasnjuguna76@gmail.com</span></p>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<?php include 'footer.php'?>