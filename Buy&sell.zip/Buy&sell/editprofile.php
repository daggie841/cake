<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'user-header.php';
include 'customer.php';

$cmr = new customer();

if (!isset($_SESSION["cmrId"])) {
    // JavaScript code to open a popup window
    echo '<script type="text/javascript">
            alert("Please Sign in first to edit your profile.");
            window.location.href = "index.php";
          </script>';
    exit; // Exit to prevent further execution of PHP code
}


$id = $_SESSION["cmrId"];

// Fetch customer data
$getdata = $cmr->getCustomerData($id);
if (!$getdata) {
    die('You are needed to logout and login a fresh to proceed...');
}
$result = $getdata->fetch_assoc();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Capture and sanitize form data
    $data = [
        'name' => htmlspecialchars($_POST['name']),
        'phone' => htmlspecialchars($_POST['phone']),
        'email' => htmlspecialchars($_POST['email']),
        'address' => htmlspecialchars($_POST['address']),
        'country' => htmlspecialchars($_POST['country']),
    ];

    // Update customer data
    $updateStatus = $cmr->customerUpdate($data, $id);

    // Check if update was successful
    if ($updateStatus) {
        // Redirect to profile page
        header('Location: profile.php');
        exit();
    } else {
        $error = 'Error updating profile. Please try again.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Profile</title>
    <style>
        .content {
            padding: 20px;
        }
        .tblone {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .tblone th, .tblone td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .tblone th {
            background-color: #f8f8f8;
        }
        .tblone input[type="text"], .tblone input[type="email"] {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .tblone input[type="submit"] {
            padding: 10px 15px;
            border: none;
            background-color: orange;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
        }
        .tblone input[type="submit"]:hover {
            background-color: green;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        
        
       
        
        
    </style>
</head>
<body>
<div class="main">
    <div class="content">
        <div class="section group">
            <?php if (!isset($_SESSION["cmrId"])): ?>
                <p>Please login first to edit your profile.</p>
            <?php else: ?>
                <form action='' method="POST">
                    <table class="tblone">
                        <tr>
                            <td colspan="3"><h2>Edit Your Profile Details</h2></td>
                        </tr>
                        <?php if (isset($error)): ?>
                            <tr>
                                <td colspan="3" style="color: red; text-align: center;"><?php echo $error; ?></td>
                            </tr>
                        <?php endif; ?>
                        <tr>
                            <td>Full Name</td>
                            <td>:</td>
                            <td><input type="text" name="name" value="<?php echo htmlspecialchars($result['name']); ?>"></td>
                        </tr>
                        <tr>
                            <td>Phone</td>
                            <td>:</td>
                            <td><input type="text" name="phone" value="<?php echo htmlspecialchars($result['phone']); ?>"></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td>:</td>
                            <td><input type="email" name="email" value="<?php echo htmlspecialchars($result['email']); ?>"></td>
                        </tr>
                        <tr>
                            <td>Town Address</td>
                            <td>:</td>
                            <td><input type="text" name="address" value="<?php echo htmlspecialchars($result['address']); ?>"></td>
                        </tr>
                        <tr>
                            <td>County</td>
                            <td>:</td>
                            <td><input type="text" name="country" value="<?php echo htmlspecialchars($result['country']); ?>"></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td><input type="submit" value="Update"></td>
                        </tr>
                    </table>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>

<?php include 'footer.php'; ?>
