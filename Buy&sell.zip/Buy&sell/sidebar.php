<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toggle Sidebar</title>
    <style>
       

        .hamburger-menu {
            display: flex;
            flex-direction: column;
            justify-content: space-around;
            width: 30px;
            height: 30px;
            cursor: pointer;
            margin: 10px;
        }

        .hamburger-menu .line {
            width: 60%;
            height: 3px;
            background-color: black;
            transition: background-color 0.3s;
        }

        .grid_2 {
            width: 250px;
            background-color: #f4f4f4;
            position: fixed;
            top: 215px; /* 70px from the top */
            left: -250px;
            height: calc(100% - 215px); /* Adjust height to fill the rest of the viewport */
            overflow-y: auto;
            transition: left 0.3s ease;
            z-index: 1000;
        }

        .grid_2.show {
            position: flex;
            left: 0;
        }

        .grid_2 .box {
            border: 1px solid #ccc;
            
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin: 30px;
        }

        .grid_2 .box a {
            display: block;
            padding: 10px;
            text-align: center;
            text-decoration: none;
            color: black;
            transition: background-color 0.3s, color 0.3s;
        }

    </style>
</head>
<body>

<div class="hamburger-menu" id="hamburger-menu">
    <div class="line"></div>
    <div class="line"></div>
    <div class="line"></div>
</div>

<div class="grid_2" id="sidebar">
    <div class="box sidemenu">
        <div class="block" id="section-menu">
            <ul class="section menu">
                <div class="grid_12">
                    <ul class="submenu">
                         <?php if ($is_logged_in): ?>
                        <a href="logout.php">Logout</a>
                    <?php else: ?>
                        <a href="login.php">Sign In</a>
                    <?php endif; ?>
                     <a href="create-user.php">Sign Up</a>
                
                    </ul>
                </div>
            </ul>
        </div>
    </div>
</div>

<script>
    document.getElementById('hamburger-menu').addEventListener('click', function() {
        document.getElementById('sidebar').classList.toggle('show');
    });

    document.addEventListener('click', function(event) {
        const sidebar = document.getElementById('sidebar');
        const isClickInside = sidebar.contains(event.target) || document.getElementById('hamburger-menu').contains(event.target);

        if (!isClickInside) {
            sidebar.classList.remove('show');
        }
    });
</script>

</body>
</html>
