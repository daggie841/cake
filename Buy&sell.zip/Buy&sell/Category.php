<?php
include_once 'Database.php';
include_once 'Formate.php';

class Category {
    private $conn;
    private $fm;

    public function __construct() {
        $this->conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

        // Check connection
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }

        $this->fm = new Format();
    }

    public function catInsert($catname) {
        $catname = $this->fm->validation($catname);

        if (empty($catname)) {
            return "<span class='error'>Category field must not be empty!</span>";
        } else {
            $query = "INSERT INTO tbl_category (catname) VALUES (?)";
            $stmt = $this->conn->prepare($query);

            if (!$stmt) {
                die("Failed to prepare statement: " . $this->conn->error);
            }

            $stmt->bind_param("s", $catname);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                return "<span class='success'>Category inserted successfully.</span>";
            } else {
                return "<span class='error'>Category not inserted.</span>";
            }
        }
    }

    public function getAllCat() {
        $query = "SELECT * FROM tbl_category ORDER BY catid DESC";
        $result = $this->conn->query($query);

        if (!$result) {
            die("Error in query: " . $this->conn->error);
        }

        $categories = array();
        while ($row = $result->fetch_assoc()) {
            $categories[] = $row;
        }

        return $categories;
    }

    public function getCatById($id) {
        $query = "SELECT * FROM tbl_category WHERE catid = ?";
        $stmt = $this->conn->prepare($query);

        if (!$stmt) {
            die("Failed to prepare statement: " . $this->conn->error);
        }

        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if (!$result) {
            die("Error in query: " . $this->conn->error);
        }

        return $result->fetch_assoc();
    }

    public function catUpdate($catname, $id) {
        $catname = $this->fm->validation($catname);

        if (empty($catname)) {
            return "<span class='error'>Category field must not be empty!</span>";
        } else {
            $query = "UPDATE tbl_category SET catname = ? WHERE catid = ?";
            $stmt = $this->conn->prepare($query);

            if (!$stmt) {
                die("Failed to prepare statement: " . $this->conn->error);
            }

            $stmt->bind_param("si", $catname, $id);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                return "<span class='success'>Category updated successfully.</span>";
            } else {
                return "<span class='error'>Category not updated!</span>";
            }
        }
    }

    public function delcatById($id) {
        $query = "DELETE FROM tbl_category WHERE catid = ?";
        $stmt = $this->conn->prepare($query);

        if (!$stmt) {
            die("Failed to prepare statement: " . $this->conn->error);
        }

        $stmt->bind_param("i", $id);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            return "<span class='success'>Category deleted successfully.</span>";
        } else {
            return "<span class='error'>Category not deleted!</span>";
        }
    }
}
?>
