<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chicken Disease</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background: #333;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }

        header h1 {
            margin: 0;
        }

        nav ul {
            list-style: none;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin: 0 10px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
        }

        main {
            padding: 20px;
        }

        .intro {
            margin-bottom: 20px;
            background: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .diseases article {
            background: #fff;
            margin-bottom: 20px;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .diseases article h2 {
            margin-top: 0;
        }

        footer {
            background: #333;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            position: fixed;
            width: 100%;
            bottom: 0;
        }

        .responsive-img {
            width: 100%;
            height: auto;
            max-width: 100%;
        }

        .image-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        @media (max-width: 768px) {
            
            .image-container {
            width: 50%;
            height: 70vh;
            max-width: 50%;
        }
           
        }
    </style>
     
    

    <header>
        <h1>Common Diseases To Chickens</h1>
    </header>
    <a href="index.php">Back</a>
    <main>
        <section class="intro">
            <h2>Introduction</h2>
            <p>This page provides detailed information about 20 different diseases that affect our chickens, from 1-day-old chicks to mature hens and cocks.</p>
        </section>
        <section class="diseases">
            <article>
                <h2>1. Newcastle Disease</h2>
                <p>Newcastle disease is a highly contagious viral disease of all species of birds. 
                It is spread by direct contact with bodily fluids from infected birds and can be carried on shoes, clothing, and equipment. 
                It can cause a variety of signs and kills many of the birds that are infected.<br>
                <div class="image-container">
                    <img src="image/newcastle-disease.jpg" class="responsive-img">
                    <!--<img src="image/newcastle.jpg" class="responsive-img">-->
                </div>
                <b><u>Symptoms of the disease are:</u></b><br>
                1. Dullness & dizziness<br>
                2. Paralysis of legs and wings<br>
                3. Twisting of the neck<br>
                4. Difficulty in breathing<br>
                5. Green diarrhoea<br>
                6. Ultimate death.<br>
                </p>
            </article>
            <article>
                <h2>2. Infectious Bursal Disease (Gumboro)</h2>
                <p>This disease affects young chickens, typically between 3 to 6 weeks old. It causes immunosuppression, leading to increased susceptibility to other diseases.<br>
                Infectious bursal disease (IBD), also known as Gumboro disease, infectious bursitis, and infectious avian nephrosis, 
                is a highly contagious disease of young chickens and turkeys caused by infectious bursal disease virus (IBDV),
                <div class="image-container">
                    <!--<img src="image/Gumboro.png" class="responsive-img">-->
                    <img src="image/Bursal.jpg" class="responsive-img">
                </div>
                [1] characterized by immunosuppression and mortality generally at 3 to 6 weeks of age.
                The disease was first discovered in Gumboro, Delaware in 1962.
                It is economically important to the poultry industry worldwide due to increased susceptibility to other 
                diseases and negative interference with effective vaccination.
                In recent years, very virulent strains of IBDV (vvIBDV), causing severe mortality in chicken,
                have emerged in Europe, Latin America, South-East Asia, Africa, and the Middle East. 
                Infection is via the oro-fecal route, with affected birds excreting high levels of the virus for approximately 2 weeks after infection. 
                The disease is easily spread from infected chickens to healthy chickens through food, water, and physical contact.[2]</p>
            </article>
            <!-- Add more articles for each disease -->
            <article>
                <h2>3. Marek's Disease</h2>
                <p>Marek's Disease is caused by a herpesvirus and primarily affects young chickens. It leads to tumors and paralysis.</p>
            </article>
            <article>
                <h2>4. Avian Influenza</h2>
                <p>Avian Influenza, also known as bird flu, is a viral infection that can affect chickens. Symptoms include respiratory issues, decreased egg production, and high mortality.</p>
            </article>
            <article>
                <h2>5. Coccidiosis</h2>
                <p>Coccidiosis is a parasitic disease that affects the intestines of chickens. It is characterized by diarrhea, weight loss, and reduced growth rates.</p>
            </article>
            <article>
                <h2>6. Fowl Cholera</h2>
                <p>Fowl Cholera is a bacterial disease that affects chickens of all ages. Symptoms include fever, diarrhea, and sudden death.</p>
            </article>
            <article>
                <h2>7. Infectious Bronchitis</h2>
                <p>This viral disease affects the respiratory system of chickens. Symptoms include coughing, sneezing, and reduced egg production.</p>
            </article>
            <article>
                <h2>8. Mycoplasmosis</h2>
                <p>Mycoplasmosis is a bacterial disease that affects the respiratory system of chickens. Symptoms include coughing, nasal discharge, and decreased egg production.</p>
            </article>
            <article>
                <h2>9. Salmonellosis</h2>
                <p>Salmonellosis is a bacterial disease that affects the digestive system of chickens. Symptoms include diarrhea, lethargy, and reduced growth rates.</p>
            </article>
            <article>
                <h2>10. Avian Encephalomyelitis</h2>
                <p>This viral disease affects the nervous system of chickens. Symptoms include tremors, paralysis, and decreased egg production.</p>
            </article>
            <article>
                <h2>11. Fowl Pox</h2>
                <p>Fowl Pox is a viral disease that affects the skin and mucous membranes of chickens. Symptoms include lesions on the skin and respiratory issues.</p>
            </article>
            <article>
                <h2>12. Aspergillosis</h2>
                <p>Aspergillosis is a fungal disease that affects the respiratory system of chickens. Symptoms include difficulty breathing, lethargy, and weight loss.</p>
            </article>
            <article>
                <h2>13. Egg Drop Syndrome</h2>
                <p>This viral disease affects the reproductive system of hens. Symptoms include a sudden drop in egg production and poor egg quality.</p>
            </article>
            <article>
                <h2>14. Lymphoid Leukosis</h2>
                <p>Lymphoid Leukosis is a viral disease that causes tumors in chickens. Symptoms include weight loss, weakness, and decreased egg production.</p>
            </article>
            <article>
                <h2>15. Infectious Coryza</h2>
                <p>This bacterial disease affects the respiratory system of chickens. Symptoms include nasal discharge, swelling of the face, and reduced egg production.</p>
            </article>
            <article>
                <h2>16. Pullorum Disease</h2>
                <p>Pullorum Disease is a bacterial infection that primarily affects young chicks. Symptoms include white diarrhea, lethargy, and high mortality rates.</p>
            </article>
            <article>
                <h2>17. Colibacillosis</h2>
                <p>Colibacillosis is a bacterial disease caused by E. coli. Symptoms include respiratory issues, diarrhea, and decreased growth rates.</p>
            </article>
            <article>
                <h2>18. Necrotic Enteritis</h2>
                <p>This bacterial disease affects the intestines of chickens. Symptoms include diarrhea, lethargy, and sudden death.</p>
            </article>
            <article>
                <h2>19. Infectious Laryngotracheitis</h2>
                <p>This viral disease affects the respiratory system of chickens. Symptoms include coughing, difficulty breathing, and decreased egg production.</p>
            </article>
            <article>
                <h2>20. Botulism</h2>
                <p>Botulism is a bacterial disease caused by toxins produced by Clostridium botulinum. Symptoms include paralysis, weakness, and sudden death.</p>
            </article>
        </section>
    </main>
    <footer>
        <p>&copy; 2024 Chicken Disease</p>
    </footer>
</body>
</html>
