<?php
include_once 'admin-header.php';
include_once 'Database.php';
include_once 'Formate.php';

class Category {
    private $conn;
    private $fm;

    public function __construct() {
        $this->conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

        // Check connection
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }

        $this->fm = new Format();
    }

    public function catInsert($catName) {
        $catName = $this->fm->validation($catName);

        if (empty($catName)) {
            return "<span class='message error'>Category field must not be empty!</span>";
        } else {
            $query = "INSERT INTO tbl_category (catName) VALUES (?)";
            $stmt = $this->conn->prepare($query);

            if (!$stmt) {
                die("Failed to prepare statement: " . $this->conn->error);
            }

            $stmt->bind_param("s", $catName);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                return "<span class='message success'>Category inserted successfully.</span>";
            } else {
                return "<span class='message error'>Category not inserted.</span>";
            }
        }
    }

    public function getAllCat() {
        $query = "SELECT * FROM tbl_category ORDER BY catId DESC";
        $result = $this->conn->query($query);

        if (!$result) {
            die("Error in query: " . $this->conn->error);
        }

        $categories = array();
        while ($row = $result->fetch_assoc()) {
            $categories[] = $row;
        }

        return $categories;
    }

    public function getCatById($id) {
        $query = "SELECT * FROM tbl_category WHERE catId = ?";
        $stmt = $this->conn->prepare($query);

        if (!$stmt) {
            die("Failed to prepare statement: " . $this->conn->error);
        }

        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if (!$result) {
            die("Error in query: " . $this->conn->error);
        }

        return $result->fetch_assoc();
    }

    public function catUpdate($catName, $id) {
        $catName = $this->fm->validation($catName);

        if (empty($catName)) {
            return "<span class='message error'>Category field must not be empty!</span>";
        } else {
            $query = "UPDATE tbl_category SET catName = ? WHERE catId = ?";
            $stmt = $this->conn->prepare($query);

            if (!$stmt) {
                die("Failed to prepare statement: " . $this->conn->error);
            }

            $stmt->bind_param("si", $catName, $id);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                return "<span class='message success'>Category updated successfully.</span>";
            } else {
                return "<span class='message error'>Category not updated!</span>";
            }
        }
    }

    public function delcatById($id) {
        $query = "DELETE FROM tbl_category WHERE catId = ?";
        $stmt = $this->conn->prepare($query);

        if (!$stmt) {
            die("Failed to prepare statement: " . $this->conn->error);
        }

        $stmt->bind_param("i", $id);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            return "<span class='message success'>Category deleted successfully.</span>";
        } else {
            return "<span class='message error'>Category not deleted!</span>";
        }
    }
}

// Create an instance of the Category class
$category = new Category();

// Handle form submissions for delete and edit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['delete'])) {
        $catId = $_POST['catId'];
        $message = $category->delcatById($catId);
    } elseif (isset($_POST['edit'])) {
        $catId = $_POST['catId'];
        $catName = $_POST['catName'];
        $message = $category->catUpdate($catName, $catId);
    } elseif (isset($_POST['add'])) {
        $catName = $_POST['catName'];
        $message = $category->catInsert($catName);
    }
}

// Handle get request for editing
if (isset($_GET['edit_id'])) {
    $catId = $_GET['edit_id'];
    $catData = $category->getCatById($catId);
}

// Retrieve all categories
$categories = $category->getAllCat();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Category List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 0;
        }
        h1, h2 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        a {
            color: #007BFF;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .message {
            display: block;
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid transparent;
            border-radius: 5px;
        }
        .success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }
        .error {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
        }
        form {
            display: inline;
        }
        input[type="text"] {
            padding: 5px;
            margin-right: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        input[type="submit"] {
            padding: 5px 10px;
            border: none;
            border-radius: 4px;
            background-color: #007BFF;
            color: white;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        input[type="submit"].delete {
            background-color: #dc3545;
        }
        input[type="submit"].delete:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <h1>Category List</h1>
    <?php if (isset($message)) echo $message; ?>

    <table>
        <thead>
            <tr>
                <th>Category Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($categories as $cat): ?>
                <tr>
                    <td><?php echo htmlspecialchars($cat['catName']); ?></td>
                    <td>
                        <!-- Edit Category Link -->
                        <a href="?edit_id=<?php echo $cat['catId']; ?>">Edit</a>
                        <!-- Delete Category Form -->
                        <form method="POST" action="" onsubmit="return confirm('Are you sure you want to delete this category?');" style="display:inline;">
                            <input type="hidden" name="catId" value="<?php echo $cat['catId']; ?>">
                            <input type="submit" name="delete" value="Delete" class="delete">
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if (isset($catData)): ?>
        <h2>Edit Category</h2>
        <form method="POST" action="">
            <input type="hidden" name="catId" value="<?php echo $catData['catId']; ?>">
            <input type="text" name="catName" value="<?php echo htmlspecialchars($catData['catName']); ?>">
            <input type="submit" name="edit" value="Update">
        </form>
    <?php else: ?>
        <h2>Add New Category</h2>
        <form method="POST" action="">
            <input type="text" name="catName" placeholder="Enter category name">
            <input type="submit" name="add" value="Add Category">
            <a href="admin_dashboard.php">Back To Dashboaerd</a>
        </form>
    <?php endif; ?>
</body>
</html>
