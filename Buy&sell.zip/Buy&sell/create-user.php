<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once 'user-header.php';
include_once 'customer.php';

$cmr = new customer();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $customerReg = $cmr->customerRegistration($_POST);
}
?>

<div class="main">
    <div class="content">
        <div class="register_account">
            <?php 
            if (isset($customerReg)) {
                echo $customerReg;
            }
            ?>
            <h3>Don't have an account? Register!</h3>
            <form action="" method="post">
                <table>
                    <tbody>
                    <tr>
                    <td>
                        <div>
                            <input type="text" name="name" placeholder="Full Name"/>
                        </div>
                        <div>
                            <input type="text" name="email" placeholder="Email"/>
                        </div>
                        <div>
                            <input type="text" name="country" placeholder="County"/>
                        </div>
                        <div>
                            <input type="text" name="address" placeholder="Town Address"/>
                        </div>
                        <div>
                            <input type="text" name="phone" placeholder="Phone"/>
                        </div>
                        <div>
                            <input type="text" name="pass" placeholder="Password"/>
                        </div>
                    </td>
                    </tr> 
                    </tbody>
                </table> 
                <div class="search">
                    <button class="grey" name="register">Create Account
                    </button>
                </div>
                <div class="clear"></div>
            </form>
        </div>  	
        <div class="clear"></div>
    </div>
</div>

<?php include 'footer.php'; ?>


<style>


    .register_account {
        margin-bottom: 20px;
    }

    .register_account h3 {
        font-size: 18px;
        color: #333;
    }

    .register_account form {
        margin-top: 10px;
    }

    .register_account table {
        width: 90%;
        border-collapse: collapse;
    }

    .register_account input[type="text"], .register_account input[type="password"] {
        width: calc(100% - 20px);
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ddd;
        border-radius: 8px;
        box-sizing: border-box;
    }

    .search button {
        background-color: orange;
        color: #fff;
        border: none;
        padding: 10px 20px;
        border-radius: 20px;
        cursor: pointer;
    }

    .search button:hover {
        background-color: green;
    }
</style>

