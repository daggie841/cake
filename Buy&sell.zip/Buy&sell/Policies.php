<?php include 'user-header.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device, initial-scale=1.0">
  <title>privacy and policies</title>

</head>
<body>
  <header>
    <h1><B>SIKAM FARMS</B></h1>
  </header>
  
    <p>
<h2 style="color: blue; font-weight: bold;">Privacy And Policy</h2>

<p>At Sikam Farm, we are committed to protecting your privacy and ensuring the security of your personal information. This Privacy Policy outlines how we collect, use, disclose, and protect your information when you visit our website or engage with our services.</p>

<H3 style="color: blue; font-weight: bold;">Information We Collect</h3>

<p>Personal Information: When you interact with our website or services, we may collect personal information such as your name, email address, phone number, and address.
Payment Information: If you make a purchase, we may collect payment information such as credit card details.
Usage Information: We may collect information about how you interact with our website, including your IP address, browser type, device type, and pages visited.</p>
<h4 style="color: blue; font-weight: bold;"> How We Use Your Information</h4>

<p>To Provide Services: We use your information to fulfill orders, process payments, and provide customer support.
Communication: We may use your contact information to send you updates, newsletters, and promotional offers. You can opt out of these communications at any time.
Improve Our Services: We analyze usage data to improve our website, products, and services.
Legal Compliance: We may use your information to comply with legal obligations or protect our rights.</p>
<h5 style="color: blue; font-weight: bold;">Data Security </h5>

<p>We employ industry-standard security measures to protect your personal information from unauthorized access, disclosure, alteration, or destruction.</p>

<h6 style="color: blue; font-weight: bold;">Third-Party Disclosure</h6>

<p>We do not sell, trade, or otherwise transfer your personal information to third parties without your consent, except as required to provide services or comply with legal obligations.</p>

<h7 style="color: blue; font-weight: bold;">Your Rights</h7>

<p>You have the right to access, correct, or delete your personal information. You can also opt out of marketing communications at any time.</p>

<h8 style="color: blue; font-weight: bold;">Changes to This Policy</h8>

<p>We may update this Privacy Policy from time to time. Any changes will be posted on this page, and we encourage you to review this Policy periodically.
</p>
<h9 style="color: blue; font-weight: bold;">Contact Us</h9>

<p>If you have any questions or concerns about this Privacy Policy, please contact us
 <style>
body {

  margin-left: 50px;
  padding: 10px;
  background-color: white; <--Change background color as needed -->
}

header {
  color: black; /* Change header text color as needed */
  padding: 4px;
  font-size: 15px;
  text-align: center;
}

h1 {
  font-size: 36px;
  font-weight: bold;
}

p {
  font-size: 18px;
  line-height: 1.5;
  color: #333; <-- Change paragraph text color as needed -->
  margin: 0px;
}

</style>
 
</body>
</html>
<?php include 'footer.php';?>