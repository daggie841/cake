<?php
session_start();

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Not logged in, redirect to login page
    header("Location: adminlogin.php");
    exit;
}


// Include necessary files
include_once 'admin-header.php';
include_once 'Formate.php';
include_once 'Cart.php';

// Create an instance of the cart class
$ct = new Cart();

// Check if shiftid parameter is set in the URL
if (isset($_GET['shiftid'])) {
    $id = $_GET['shiftid'];
    // Call the productShifted method of the cart class
    $shift = $ct->productShifted($id);
}

// Check if delproid parameter is set in the URL
if (isset($_GET['delproid'])) {
    $id = $_GET['delproid'];
    // Call the delProductShifted method of the cart class
    $delOrder = $ct->delProductShifted($id);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Your Title Here</title>
</head>
<body>
<div class="grid_10">
    <div class="box round first grid">
        <h2>Orders</h2>
        <?php 
        // Display messages if set
        if (isset($shift)) {
            echo $shift;
        }

        if (isset($delOrder)) {
            echo $delOrder;
        }
        ?>
        <div class="block">        
            <table class="data display datatable" id="example">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Order Time</th>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Address</th>
                        <th>Action</th>
                        <th>Order info</th>
                         <!--<th>Payments</th>-->
                        
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Create an instance of the Format class
                    $fm = new Format();
                    // Call the getAllOrderProduct method of the cart class to fetch orders
                    $getOrder = $ct->getAllOrderProduct();
                    if ($getOrder && $getOrder->num_rows > 0) {
                        while ($result = $getOrder->fetch_assoc()) {
                    ?>
                    <tr class="odd gradeX">
                        <!-- Display order details -->
                        <td><?php echo $result['id']; ?></td>
                        <td><?php echo $fm->formatDate($result['date']); ?></td>
                        <td><?php echo $result['productName']; ?></td>
                        <td><?php echo $result['quantity']; ?></td>
                        <td>ksh. <?php echo $result['price']; ?></td>
                        <td><a href="viewdetails.php?custId=<?php echo $result['cmrId']; ?>">View Details</a></td>
                        <td><a href="?delproid=<?php echo $result['id']; ?>">Delete</a></td>

                        <?php 
                        // Determine order status and display appropriate action
                        if ($result['status'] == '0') { ?>
                        <td><a href="?shiftid=<?php echo $result['id']; ?>">Waiting order</a></td>    
                        <?php } elseif($result['status'] =='1'){?>
                            <td><a href="?orderreceivedid=<?php echo $result['id']; ?>">Order received</a></td>
                        <?php } else { ?>
                            <td><a href="?ordercompleteid=<?php echo $result['id']; ?>">Order Complete</a></td>
                        <?php } ?>
                    </tr>
                    <?php 
                        }
                    } else {
                        // Display message if no orders found
                        echo "<tr><td colspan='8'>No orders found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>

<!-- CSS styles -->
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        font-size: 14px; /* Adjust font size for readability */
        margin: 0 auto;
        padding: 0;
    }

    .grid_10 {
        width: 100%;
        margin: 0px;
        background-color: #fff;
        padding: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .box.round {
        border-radius: 10px;
        padding: 0px;
    }

    h2 {
        color: #333;
        border-bottom: 2px solid #333;
        padding-bottom: 10px;
    }

    .block {
        margin-top: 20px;
    }

    table {
        width: 100%; /* Adjust table width for better responsiveness */
        border-collapse: collapse;
        margin-top: 20px;
    }

    table th, table td {
        padding: 5px; /* Reduce padding for better fitting */
        text-align: left;
        border-bottom: 2px solid #ddd;
         border: 2px solid #ddd;
    }

    table th {
        background-color: #f4f4f4;
    }

    table tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    .odd.gradeX {
        background-color: #fff;
    }

    a {
        color: #3498db;
        text-decoration: none;
    }

    a:hover {
        text-decoration: underline;
    }

    /* Media Query for Phones */
    @media only screen and (max-width: 600px) {
        body {
            font-size: 8px; /* Adjust font size for smaller screens */
        }
        table th, {
            padding: 8px; /* Further reduce padding for better fitting */
        }
         .grid_10 {
            width: 96%; /* Adjust grid width for larger screens */
        }
    }

    /* Media Query for Laptops */
    @media only screen and (min-width: 601px) {
        .grid_10 {
            width: 100%; /* Adjust grid width for larger screens */
        }
    }
</style>

<?php include 'adminfooter.php'; ?>
