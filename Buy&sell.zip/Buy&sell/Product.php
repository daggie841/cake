<?php
// Including necessary files for database connection and format handling
include_once 'Database.php'; // Assuming Database.php is in the same directory
include_once 'Formate.php';

class Product {
    private $db;
    private $fm;

    // Constructor to initialize Database and Format objects
    public function __construct() {
        $this->db = new Database();
        $this->fm = new Format();
    }

    // Retrieve all categories for displaying in a sidebar
    public function getAllCategories() {
        $query = "SELECT * FROM tbl_category ORDER BY catName ASC";
        return $this->db->select($query);
    }

    // Retrieve all products from the shop, ordered by product ID in descending order
    public function getAllProducts() {
        $query = "SELECT * FROM tbl_product ORDER BY productId DESC";
        return $this->db->select($query);
    }

    // Retrieve products based on the category ID
    public function productByCat($catId) {
        $query = "SELECT * FROM tbl_product WHERE catId = '$catId'";
        $result = $this->db->select($query);
        return $result;
    }

    // Retrieve a product by its ID
    public function getProductById($id) {
        $id = $this->db->escapeString($id);
        $query = "SELECT * FROM tbl_product WHERE productId = '$id'";
        return $this->db->select($query);
    }

    // Search for products based on the query string
    public function searchProducts($query) {
        $query = $this->db->escapeString($query);
        $sql = "SELECT * FROM tbl_product WHERE productName LIKE '%$query%' OR body LIKE '%$query%'";
        return $this->db->select($sql);
    }

    // Insert a new product into the database
    public function productInsert($data, $file) {
        // Validate and escape product data
        $productName = $this->fm->validation($data['productName']);
        $catName = $this->fm->validation($data['catName']); // Change from catId to catName
        $brandId = $this->fm->validation($data['brandId']);
        $body = $this->fm->validation($data['body']);
        $price = $this->fm->validation($data['price']);
        $type = $this->fm->validation($data['type']);

        $productName = mysqli_real_escape_string($this->db->link, $productName);
        $catName = mysqli_real_escape_string($this->db->link, $catName); // Corrected variable name
        $brandId = mysqli_real_escape_string($this->db->link, $brandId);
        $body = mysqli_real_escape_string($this->db->link, $body);
        $price = mysqli_real_escape_string($this->db->link, $price);
        $type = mysqli_real_escape_string($this->db->link, $type);

        // Handle file upload
        $permited = array('jpg', 'jpeg', 'png', 'gif');
        $file_name = $file['image']['name'];
        $file_size = $file['image']['size'];
        $file_temp = $file['image']['tmp_name'];

        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $unique_image = uniqid() . '.' . $file_ext;
        $uploaded_image = "image/" . $unique_image;

        // Check for errors in product data and file
        if (empty($productName) || empty($catName) || empty($brandId) || empty($body) || empty($price) || empty($file_name) || empty($type)) {
            return "<span class='error'>Fields must not be empty!</span>";
        } elseif ($file_size > 1048576) {
            return "<span class='error'>Image Size should be less than 1MB!</span>";
        } elseif (!in_array($file_ext, $permited)) {
            return "<span class='error'>You can upload only: " . implode(', ', $permited) . "</span>";
        } else {
            if (move_uploaded_file($file_temp, $uploaded_image)) {
                // Retrieve the category ID from the category name
                $catQuery = "SELECT catName FROM tbl_category WHERE catName = '$catName'";
                $catResult = $this->db->select($catQuery);
                if ($catResult) {
                    $catRow = $catResult->fetch_assoc();
                    $catName  = $catRow['catName '];

                    $query = "INSERT INTO tbl_product(productName, catName, brandId, body, price, image, type) 
                              VALUES('$productName', '$catName', '$brandId', '$body', '$price', '$uploaded_image', '$type')";
                    $inserted_row = $this->db->insert($query);
                    if ($inserted_row) {
                        return "<span class='success'>Product inserted successfully.</span>";
                    } else {
                        return "<span class='error'>Product not inserted.</span>";
                    }
                } else {
                    return "<span class='error'>Category not found.</span>";
                }
            } else {
                return "<span class='error'>Image upload failed.</span>";
            }
        }
    }

    // Retrieve all products with category and brand details
    public function getAllProduct() {
        $query = "SELECT tbl_product.*, tbl_category.catName, tbl_brand.brandName
                  FROM tbl_product
                  INNER JOIN tbl_category ON tbl_product.catName = tbl_category.catName
                  INNER JOIN tbl_brand ON tbl_product.brandId = tbl_brand.brandId
                  ORDER BY tbl_product.productId DESC";
        $result = $this->db->select($query);

        if ($result === false) {
            echo "Error executing query: " . $this->db->link->error;
            return false;
        } else if ($result->num_rows == 0) {
            echo "No products found in the database.";
            return false;
        }

        return $result;
    }

    // Retrieve a product by its ID
    public function getProById($id) {
        $query = "SELECT * FROM tbl_product WHERE productId = '$id'";
        $result = $this->db->select($query);
        return $result;
    }

    // Update an existing product's details
    public function productUpdate($data, $file, $id) {
        // Validate and escape product data
        $productName = $this->fm->validation($data['productName']);
        $catName = $this->fm->validation($data['catName']); // Change from catId to catName
        $brandId = $this->fm->validation($data['brandId']);
        $body = $this->fm->validation($data['body']);
        $price = $this->fm->validation($data['price']);
        $type = $this->fm->validation($data['type']);

        $productName = mysqli_real_escape_string($this->db->link, $productName);
        $catName = mysqli_real_escape_string($this->db->link, $catName); // Corrected variable name
        $brandId = mysqli_real_escape_string($this->db->link, $brandId);
        $body = mysqli_real_escape_string($this->db->link, $body);
        $price = mysqli_real_escape_string($this->db->link, $price);
        $type = mysqli_real_escape_string($this->db->link, $type);

        // Handle file upload
        $permited = array('jpg', 'jpeg', 'png', 'gif');
        $file_name = $file['image']['name'];
        $file_size = $file['image']['size'];
        $file_temp = $file['image']['tmp_name'];

        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $unique_image = uniqid() . '.' . $file_ext;
        $uploaded_image = "uploads/" . $unique_image;

        // Check for errors in product data and file
        if (empty($productName) || empty($catName) || empty($brandId) || empty($body) || empty($price) || empty($type)) {
            return "<span class='error'>Fields must not be empty!</span>";
        } else {
            if (!empty($file_name)) {
                if ($file_size > 1048576) {
                    return "<span class='error'>Image Size should be less than 1MB!</span>";
                } elseif (!in_array($file_ext, $permited)) {
                    return "<span class='error'>You can upload only: " . implode(', ', $permited) . "</span>";
                } else {
                    move_uploaded_file($file_temp, $uploaded_image);

                    // Retrieve the category ID from the category name
                    $catQuery = "SELECT catName FROM tbl_category WHERE catName = '$catName'";
                    $catResult = $this->db->select($catQuery);
                    if ($catResult) {
                        $catRow = $catResult->fetch_assoc();
                        $catName = $catRow['catName'];

                        $query = "UPDATE tbl_product 
                                  SET productName = '$productName', catName = '$catName', brandId = '$brandId', 
                                      body = '$body', price = '$price', image = '$uploaded_image', type = '$type'
                                  WHERE productId = '$id'";
                        $updated_row = $this->db->update($query);
                        if ($updated_row) {
                            return "<span class='success'>Product Updated Successfully.</span>";
                        } else {
                            return "<span class='error'>Product Not Updated.</span>";
                        }
                    } else {
                        return "<span class='error'>Category not found.</span>";
                    }
                }
            } else {
                // Retrieve the category ID from the category name
                $catQuery = "SELECT catName FROM tbl_category WHERE catName = '$catName'";
                $catResult = $this->db->select($catQuery);
                if ($catResult) {
                    $catRow = $catResult->fetch_assoc();
                    $catName = $catRow['catName'];

                    $query = "UPDATE tbl_product 
                              SET productName = '$productName', catName = '$catName', brandId = '$brandId', 
                                  body = '$body', price = '$price', type = '$type'
                              WHERE productId = '$id'";
                    $updated_row = $this->db->update($query);
                    if ($updated_row) {
                        return "<span class='success'>Product Updated Successfully.</span>";
                    } else {
                        return "<span class='error'>Product Not Updated.</span>";
                    }
                } else {
                    return "<span class='error'>Category not found.</span>";
                }
            }
        }
    }

    // Delete a product by its ID
    public function delProById($id) {
        $productId = intval($id);
        if ($productId <= 0) {
            return "<span class='error'>Invalid Product ID.</span>";
        }

        // Retrieve the image file associated with the product
        $query = "SELECT image FROM tbl_product WHERE productId = ?";
        $stmt = $this->db->link->prepare($query);
        if (!$stmt) {
            die('Error preparing statement: ' . $this->db->link->error);
        }
        $stmt->bind_param("i", $productId);
        $stmt->execute();
        $stmt->bind_result($dellink);
        $stmt->fetch();

        if ($dellink) {
            unlink($dellink); // Delete the image file
        }

        $stmt->close();
        $query = "DELETE FROM tbl_product WHERE productId = '$productId'";
        $deleted_row = $this->db->delete($query);

        if ($deleted_row) {
            return "<span class='success'>Product Deleted Successfully.</span>";
        } else {
            return "<span class='error'>Product Not Deleted.</span>";
        }
    }
}
?>
