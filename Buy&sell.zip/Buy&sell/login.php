<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once 'user-header.php';
include_once 'customer.php';

$cmr = new customer();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $custLogin = $cmr->customerLogin($_POST);
}
?>

<div class="main">
    <div class="content">
        <div class="login_panel">
            <?php 
            if (isset($custLogin)) {
                echo $custLogin;
            }
            ?>
            <h3><span style="font-weight:bold">Input login Info</span></h3>
            <form action="" method="post">
                <input name="email" placeholder="Email" type="text"/>
                <input name="pass" placeholder="Password" type="password"/>
                <div class="buttons"><div><button class="grey" name="login">Login</button></div></div>
                <a href="userforget_password.php">Forget password</a>
            </form>
        </div>
        <div class="clear"></div>
    </div>
</div>

<?php include 'footer.php'; ?>

<style>
  

  
    .login_panel {
        max-width:400px;
        margin: 0 auto;
    }

    .login_panel h3 {
        font-weight: bold;
        margin-bottom: 10px;
    }

    .login_panel input[type="text"]
    {
        width: 70%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    
    .login_panel input[type="password"] {
        width: 40%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .login_panel .buttons {
        text-align: center;
    }

    .login_panel .buttons div {
        margin-top: 10px;
    }

    .login_panel .buttons button {
        padding: 10px 20px;
        background-color: green;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .login_panel .buttons button.grey {
        background-color: orange;
        color: #000;
    }

    .login_panel a {
        display: block;
        text-align: center;
        margin-top: 10px;
        color: #007bff;
        text-decoration: none;
    }
</style>
