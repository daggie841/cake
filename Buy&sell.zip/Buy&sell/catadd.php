<?php include_once 'Category.php'; ?>
<?php
$cat = new Category();
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $catName = $_POST['catName'];
    $insertCat = $cat->catInsert($catName);
    if ($insertCat) {
        $message = "Successfully added";
    } else {
        $message = "Failed to add category";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New Category</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .grid_10 {
            width: 60%;
            margin: 50px auto;
        }
        .box {
            background: #fff;
            padding: 20px;
            border: 1px solid #ddd;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .box h2 {
            margin-bottom: 20px;
            color: #333;
        }
        .block {
            margin-top: 20px;
        }
        .form {
            width: 100%;
        }
        .form input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .form input[type="submit"] {
            padding: 10px 20px;
            background: #5a88ca;
            border: none;
            color: #fff;
            border-radius: 5px;
            cursor: pointer;
        }
        .form input[type="submit"]:hover {
            background: #4677b1;
        }
        .message {
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #ddd;
            background: #e9e9e9;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="grid_10">
        <div class="box round first grid">
            <h2>Add New Category</h2>
            <div class="block copyblock"> 
                <?php if (!empty($message)) { ?>
                    <div class="message"><?php echo $message; ?></div>
                <?php } ?>
                <form action="catadd.php" method="post">
                    <table class="form">                    
                        <tr>
                            <td>
                                <input type="text" name="catName" placeholder="Enter Category Name..." class="medium" />
                            </td>
                        </tr>
                        <tr> 
                            <td>
                                <input type="submit" name="submit" value="Save" />
                                <p><span style="border: 1px solid #ddd;background-color: skyblue;font-size: 12px; border-radius: 50px;"><a href="admin_dashboard.php">Go Back</p>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </div>
    <?php include 'adminfooter.php'; ?>
</body>
</html>
