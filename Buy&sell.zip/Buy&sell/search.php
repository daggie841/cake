<?php
include 'user-header.php';
include_once 'Formate.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search</title>
    <style>
        /* Your existing styles */
        .no-results {max-height: 50vh;
            font-size: 20px;
            color: red;
            margin: 20px;
        }
        .error-message {
            color: red;
            font-size: 18px;
            margin: 20px;
        }
         .product-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            margin: -10px;
        }
        .product-item {
            border: 1px solid #ddd;
            padding: 10px;
            margin: 10px;
            width: calc(100% / 2 - 20px); /* Default for phones (2 items per row) */
            box-sizing: border-box;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            box-sizing: border-box; /* Ensure padding and border are included in the width */
        }
        .product-image {
            border-radius: 20px;
            max-width: 100%;
            height: auto;
        }
        .product-price {
            color: black;
            font-weight: bold;
        }
        /*.button a {
            text-decoration: none;
            color: white;
            background-color: orange;
            padding: 5px 10px;
            border-radius: 10px;
        }
        .details {
            margin-top: 5px;
            display: inline-block;
        }*/
        .no-results {
            font-size: 20px;
            color: red;
            margin: 20px;
        }
        .error-message {
            color: red;
            font-size: 18px;
            margin: 20px;
        }

        /* Media query for tablets */
        @media (min-width: 600px) {
            .product-item {
                width: calc(100% / 3 - 20px); /* 3 items per row on tablets */
            }
        }

        /* Media query for laptops and larger screens */
        @media (min-width: 992px) {
            .product-item {
                width: calc(100% / 4 - 20px); /* 4 items per row on laptops */
            }
        }

        /* Media query for large screens */
        @media (min-width: 1200px) {
            .product-item {
                width: calc(100% / 5 - 20px); /* 5 items per row on large screens */
            }
        }
    </style>
</head>
<body>
    <div class="product-container">
        <?php
        if (isset($_GET['query'])) {
            $query = htmlspecialchars($_GET['query']);
            include_once 'Product.php';
            $product = new Product();
            $searchResults = $product->searchProducts($query);

            if ($searchResults === false) {
                echo "<p class='error-message'>Please try again later.</p>";
            } elseif ($searchResults->num_rows > 0) {
                while ($result = $searchResults->fetch_assoc()) {
                    ?>
                    <div class="product-item">
                        <a href="details.php?proid=<?php echo htmlspecialchars($result['productId']); ?>">
                            <img src="<?php echo htmlspecialchars($result['image']); ?>" class="product-image" alt="<?php echo htmlspecialchars($result['productName']); ?>">
                        </a>
                        <p><span style="color: black; font-weight: bold;"><?php echo htmlspecialchars($result['productName']); ?></span></p>
                        <div class="product-price">
                            <p>ksh. <?php echo htmlspecialchars($result['price']); ?></p>
                            <p><?php echo htmlspecialchars($result['shopname']); ?></p>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo "<p class='no-results'>No products found.</p>";
            }
        }
        ?>
    </div>
</body>
</html>

<?php
include 'footer.php';
?>
