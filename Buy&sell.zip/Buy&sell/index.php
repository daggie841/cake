<?php include 'user-header.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        .wrapper {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 40px;
        }

        .wrapper img {
            width: 50%;
            object-fit: cover;
            border-radius: 10px;
        }

        .wrapper .info {
            width: 50%;
        }

        /* Alternate layouts */
        #offer .wrapper {
            flex-direction: row;
        }

        #about .wrapper {
            flex-direction: row-reverse;
        }

        #policies .wrapper {
            flex-direction: row;
        }
         #disease .wrapper {
            flex-direction: row-reverse;
        }
        #vaccine .wrapper {
            flex-direction: row;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 24px;
            color: #333;
        }

        p {
            font-size: 16px;
            line-height: 1.6;
            color: #555;
        }

        .p1 {
            margin: 30px;
            font-size: 16px;
            line-height: 1.6;
            color: #555;
        }

        .logo-container {
            width: 100%;
            text-align: center;
        }

        .logo-container img {
            width: 100%;
            height: auto;
            max-height: 100vh; /* 100% of the viewport height */
            object-fit: cover;
            display: block;
            margin: 0 auto 20px auto;
        }

        /* Media query for small screens */
      @media (max-width: 600px) {
   .wrapper {*/
      display: flex;
       flex-direction: column;
     align-items: center;
     text-align: center;
     }

 .wrapper img {
        width: 50%;
        height: 100vh;
        object-fit: cover;
        margin-bottom: 20px;
    }

.wrapper .info {
    width: 100%;
}

    .logo-container img {
        width: 100%;
        margin-bottom: 20px;
    }

    .p1 {
        margin: 15px;
    }
}

    </style>
</head>
<body>
    
    <div class="logo-container">
        <img src="11.jpg" alt="Logo">
        <p class="p1">Welcome to Sikam Farms, your trusted partner in poultry farming! Nestled in the heart of lush landscapes, 
        Sikam Farms is dedicated to raising healthy, happy chickens. Our farm is a sanctuary where tradition meets innovation,
        ensuring the best care and quality for our feathered friends. From one-day-old chicks to mature hens and cocks,
        we pride ourselves on sustainable practices and top-notch biosecurity. Whether you're seeking high-quality eggs or robust poultry, 
        Sikam Farms promises excellence at every step. 
        Join us on a journey of nurturing nature's best, and experience the difference at Sikam Farms, where quality and care come first.</p>
    </div>
    
    <section id="offer">
        <h2>SERVICES OFFERED IN SIKAM FARMS</h2>
        <div class="wrapper">
            <img src="17.jpg" alt="Services Image 2">
            <div class="info">
                <p>
                    1. Hatching Eggs
                    We offer fertile and high-quality improved Kienyeji hatching eggs with a high hatch rate, ensuring you receive the best potential for your poultry farming.

                    2. Hatching Services
                    Bring us your eggs, and we'll return them to you as healthy chicks. We specialize in hatching fresh eggs that are seven (7) days old or younger. Incubation day is every Friday, and chicks must be picked up within 48 hours of hatching.

                    3. Day-Old Chicks
                    Our day-old chicks are healthy and come from well-managed, improved Kienyeji parent stock, ensuring strong and robust chicks for your farm.
                    Our two-week-old chicks are healthy and have been administered the first dose of both the Newcastle Disease (NCD) and Gumboro vaccines.
                    These chicks are nurtured from our high-quality parent stock.<b><a href="customer support.php">Read more</a> </b></p>
            </div>
        </div>
    </section>

    <section id="about">
        <h2>ABOUT</h2>
        <div class="wrapper">
            <img src="a1.jpg" alt="About Image 2">
            <div class="info">
                <p>Sikam chicken Farms was established in 2024. This Poultry Farm embodies a vision of supporting small farmers b
                y providing them with a reliable place where they can get their poultry products.
                Our mission is to streamline the poultry market challenges by offering a diverse range of poultry chickens, 
                catering to various needs from hatching eggs, 1-day-old chicks to mature cocks, hens, broilers, layers, and even improved kienyeji chickens.

                At Sikam Chicken Farm, we pride ourselves on being a one-stop destination for all chicken-related needs. <b><a href="about.php">Read more</a> </b></p>
            </div>
        </div>
    </section>

    <section id="policies">
        <h2>SIKAM FARMS PRIVACY AND POLICIES</h2>
        <div class="wrapper">
            <img src="8.jpeg" alt="Policies Image 2">
            <div class="info">
                <p>Privacy And Policy
                    At Sikam Farm, we are committed to protecting your privacy and ensuring the security of your personal information.
                    This Privacy Policy outlines how we collect, use, disclose, and protect your information when you visit our website or engage with our services.

                    Information We Collect
                    Personal Information: When you interact with our website or services, we may collect personal information such as your name, email address,
                    phone number, and address. Payment Information: If you make a purchase, 
                    we may collect payment information such as credit card details. Usage Information:
                    We may collect information about how you interact with our website, including your IP address, browser type, device type, and pages visited.
                    <b><a href="Policies.php">Read more</a> </b></p>
                  
            </div>
        </div>
    </section>
    
      <div class="logo-container">
        <img src="3week.jpg" alt="Logo">
        <p class="p1">Black, red, white, and naked neck chicks, as well as black-and-white combined chicks, each bring unique characteristics to poultry farming.
        Black chicks are known for their resilient nature and adaptability. Red chicks often grow into hardy birds with robust health.
        White chicks, prized for their uniform appearance, are popular for their consistent egg production. Naked neck chicks, 
        characterized by their lack of feathers around the neck, are valued for their heat tolerance and low feather management.
        Combined black-and-white chicks showcase striking plumage patterns, offering both aesthetic appeal and potential versatility in various environments.
        Each type enhances the diversity and functionality of poultry flocks.</p>
    </div>
     <section id="disease">
        <h2>DISEASES AFFECTING CHICKEN IN FARMS</h2>
        <div class="wrapper">
            <img src="image/newcastle-disease.jpg" alt="disease Image 2">
            <div class="info">
                <p>Newcastle disease is a highly contagious viral disease of all species of birds.
                It is spread by direct contact with bodily fluids from infected birds and can be carried on shoes,
                clothing, and equipment. It can cause a variety of signs and kills many of the birds that are infected.<br>
<b><u>Symptoms of the disease are:</u></b><br>
1. Dullness & dizziness.<br>
2. Paralysis of legs and wings.<br>
3. Twisting of the neck.<br>
4. Difficulty in breathing.<br>
5. Green diarrhoea.<br>
6. Ultimate death..<br>
 <b><a href="disease.php">Read more</a> </b></p>
                  
            </div>
        </div>
    </section>
         <section id="vaccine">
        <h2>CHICKEN VACCINE TO PREVENT DISEASES</h2>
        <div class="wrapper">
            <img src="image/vaccine.jpg" alt="vaccine Image 2">
            <div class="info">
                Vaccination is commonly used in commercial poultry and increasingly in backyard birds to control disease. 
                Vaccines mimic natural infection, allowing the birds to build up immunity to the disease without any of the harmful effects.
                This way you can prevent your birds getting the disease It is very important to remember that the success of the vaccination depends on good vaccination technique. 
                Vaccines are very vulnerable and are therefore easily destroyed.
 <b><a href="treatment.html">Read more</a> </b></p>
                  
            </div>
        </div>
    </section>
</body>
</html>
<?php include 'footer.php'; ?>
