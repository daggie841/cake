<?php
include_once 'user-header.php';
include_once 'Database.php'; // Ensure this path is correct

// Create a new instance of the Database class
$db = new Database();
$conn = $db->getLink(); // Use getLink() to get the database connection

// Check if an admin_id is provided in the URL
$admin_id = isset($_GET['admin_id']) ? intval($_GET['admin_id']) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mpeketoni Sells</title>
    <style>
        .product {
            border: 1px solid #ccc;
            padding: 15px;
            border-radius: 5px;
            text-align: center;
        }
        
        .h3 {
            font-size: 10px;
            text-align: center;
        }

        .product img {
            max-width: 100%;
            height: auto;
            border-radius: 5px;
        }

        .product-grid {
            display: grid;
            gap: 10px;
        }

        /* Default grid for mobile phones */
        .product-grid {
            grid-template-columns: repeat(2, 1fr);
        }

        /* Tablets */
        @media (min-width: 600px) {
            .product-grid {
                grid-template-columns: repeat(4, 1fr);
            }
        }

        /* Laptops and larger screens */
        @media (min-width: 1024px) {
            .product-grid {
                grid-template-columns: repeat(7, 1fr);
            }
        }

        .shop-name {
            font-size: 14px;
            text-decoration: none;
            line-height: 0.4;
            text-align: center; /* Center text */
            margin-bottom: 5px; /* Optional: Add some spacing after each shop name */
        }

        .message {
            text-align: center;
            margin-top: 20px;
            font-size: 18px;
            color: red;
        }

        h2 {
            text-align: center; /* Center the heading */
        }
    </style>
    <script>
        function redirectToCatshopname() {
            setTimeout(function() {
                window.location.href = 'catshopname.php';
            }, 3000); // Redirect after 3 seconds
        }
    </script>
</head>
<body>
    <?php
    // If admin_id is provided, fetch and display products
    if ($admin_id > 0) {
        // Fetch the shop name for the provided admin_id
        $queryShop = "SELECT shopname FROM adminlogin WHERE admin_id = ?";
        $stmtShop = $conn->prepare($queryShop);
        $stmtShop->bind_param("i", $admin_id);
        $stmtShop->execute();
        $resultShop = $stmtShop->get_result();

        if ($resultShop->num_rows > 0) {
            $rowShop = $resultShop->fetch_assoc();
            $shopname = htmlspecialchars($rowShop['shopname']);
            echo "<h2 style='text-align: center; font-weight: bold; font-style: italic; color: blue;'>Welcome To $shopname</h2>";

        }

        // Fetch products based on admin_id
        $query = "SELECT * FROM tbl_product WHERE admin_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $admin_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            echo "<div class='product-grid'>";
            while ($row = $result->fetch_assoc()) {
                $productId = htmlspecialchars($row['productId']);
                $productName = htmlspecialchars($row['productName']);
                $phone = htmlspecialchars($row['phone']);
                $shopname = htmlspecialchars($row['shopname']);
                $price = htmlspecialchars($row['price']);
                $image = htmlspecialchars($row['image']);

                echo "<div class='product'>";
                echo "<a href='details.php?proid=$productId'>";
                echo "<img src='$image' class='product-image' alt='$productName'>";
                echo "</a>";
                echo "<h3>$productName</h3>";
                echo "<p>Price: Ksh$price</p>";
                echo "<p>$shopname</p>";
                echo "<p>Call: $phone</p>";
                echo "</div>";
            }
            echo "</div>";
        } else {
            echo "<div class='message'>No products available for this shop. Redirecting...</div>";
            echo "<script>redirectToCatshopname();</script>";
        }
    } else {
        // Fetch categories from the `adminlogin` table
        $query = "SELECT DISTINCT admin_id, shopname FROM adminlogin";
        $result = $conn->query($query);

        echo "<h2>All shops</h2>";
        while ($row = $result->fetch_assoc()) {
            $admin_id = htmlspecialchars($row['admin_id']);
            $shopname = htmlspecialchars($row['shopname']);

            echo "<h3 class='shop-name'><a href='?admin_id=$admin_id'>$shopname</a></h3>";
        }
    }
    ?>
</body>
</html>
<?php include 'footer.php'; ?>
