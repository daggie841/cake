<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Not logged in, redirect to login page
    header("Location: adminlogin.php");
    exit;
}

include_once "admin-header.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<body>

    <div class="content-wrapper">
        <div class="sidebar">
            <ul class="menu">
                <li><a class="menuitem" href="#">Category Option</a>
                    <ul class="submenu">
                        <li><a href="catadd.php">Add Category</a></li>
                        <li><a href="catlist.php">Category List</a></li>
                    </ul>
                </li>
                <li><a class="menuitem" href="#">Product Option</a>
                    <ul class="submenu">
                        <li><a href="productadd.php">Add Product</a></li>
                        <li><a href="productlist.php">Product List</a></li>
                    </ul>
                </li>
            </ul>
        </div>
        <!-- <div class="main-content">
            <p class="welcome-message">
                Welcome to Sikam Chicken Farms, our feathered haven of prosperity! Here, each day unfolds with clucks of joy and eggs of abundance. As our esteemed admin, you'll nurture growth, ensuring our flock thrives. Together, let's hatch success, spreading wings of excellence across our coop. Happy farming!
            </p>
        </div> -->
    </div>    

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var menuItems = document.querySelectorAll('.menuitem');

            menuItems.forEach(function(item) {
                item.addEventListener('click', function(e) {
                    e.preventDefault();
                    var submenu = this.nextElementSibling;
                    // Hide all submenus first
                    document.querySelectorAll('.submenu').forEach(function(sub) {
                        sub.style.display = "none";
                    });
                    // Toggle display of clicked submenu
                    if (submenu.style.display === "block") {
                        submenu.style.display = "none";
                    } else {
                        submenu.style.display = "block";
                    }
                });
            });
        });
    </script>
</body>
</html>
<?php include "adminfooter.php"; ?>

<style>
    /* Styles omitted for brevity */
</style>



<style>
     
        .content-wrapper {
            display: flex;
            flex: 1;
        }
        .sidebar {
            width: 200px;
            height:100% auto;
            background-color: lightblue;
            display: flex;
            flex-direction: column;
        }
        .main-content {
            flex: 10;
            padding: 20px;
        }
        .menu {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }
        .menuitem {
            display: block;
            padding: 10px;
            border-bottom: 1px solid #ddd;
            color: #333;
            text-decoration: none;
        }
        .menuitem:hover {
            background-color: orange;
        }
        .submenu {
            display: none;
            background-color: white;
            list-style-type: none;
            padding: 0;
        }
        .submenu li {
            padding: 10px;
        }
        .submenu li a {
            display: block;
            color: #666;
            text-decoration: none;
        }
        .submenu li a:hover {
            color: #333;
            background-color: orange;
        }
        .welcome-message {
            font-size: 24px;
            margin-top: 50px;
        }
    </style>
