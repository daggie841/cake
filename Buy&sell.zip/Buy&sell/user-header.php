<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

ob_start(); // Start output buffering
session_start(); // Start the session
include 'Cart.php'; // Include the Cart class

// Dummy login status for demonstration (Replace with actual login logic)
$is_logged_in = isset($_SESSION['cmrId']); // Check if the session variable 'cmrId' is set

// Initialize Cart class
$cart = new Cart();

// Function to get cart item count from Cart class
function getCartItemCount($cart) {
    return $cart->getItemCount(); // Ensure method name matches
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mpeketoni.dukaletu</title>
    <style>
        /* Your existing CSS code */
        .header {
            font-family: 'Times New Roman', Times, serif;
            background-color: floralwhite;
            color: #fff;
            padding: 60px 0px;
            overflow: hidden;
            display: flex; /* Use flexbox */
            align-items: center; /* Center vertically */
        }
        .floatright {
            margin-left: auto; /* Push to the right */
            display: flex;
            align-items: center;
        }
        .img {
            border-radius: 20px;
        }
        .floatleft img {
            margin: 0px;
        }
        .nav {
            list-style: none;
            padding: 10px;
            margin: 0px;
            background-color:peachpuff;
            overflow: hidden;
            text-align: center; /* Center the navigation items */
        }
        .nav li {
            display: inline-block; /* Use inline-block for center alignment */
        }
        .nav li a {
            display: block;
            color: black;
            text-align: center;
            padding: 5px 10px;
            text-decoration: none;
        }
        .nav li a:hover {
            border-radius: 20px;
            background-color: bisque;
        }
        .vertical-menu {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
        }
        .vertical-menu a {
            display: block;
            color: black;
            text-align: center;
            padding: 3px;
            text-decoration: none;
        }
        .search-box input[type="text"],
        .search-box input[type="submit"] {
            border-radius: 3px;
            border: 1px solid #ccc;
            margin-bottom: 0px; /* Add margin for spacing between elements */
        }

        .search-box input[type="submit"] {
            padding: 3px 10px; /* Adjust padding for better touch interaction on mobile */
            background-color: orange;
            color: black;
            border: none;
            cursor: pointer;
        }

        .cart-icon {
            position: relative;
            display: inline-block;
            font-size: 24px; /* Adjust font size */
            margin-left: 0px; /* Space between other elements */
        }
        .cart-icon sup {
            position: absolute;
            top: -5px;
            right: +10px;
            background-color: red;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 12px;
        }

         .responsive-logo img {
        width: 100%;
        height: auto;
        max-width: 150px; /* Default size on larger screens */
    } 


        @media only screen and (max-width: 600px) {
            .search-box {
                display: flex;
                flex-direction: column; /* Align items vertically */
            }
               .responsive-logo img {
            max-width: 80px; /* Smaller size for phones */
        }

            .search-box input[type="text"] {
                width: 60%; /* Make inputs full width */
            }
            .search-box input[type="submit"] {
                width: 33%; /* Make inputs full width */
            }

            .nav {
                display: block;
            }
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <!-- Header section -->
    <div class="header">
       <div class="responsive-logo">
            <img src="image/logos.jpg" alt="Logo">
       </div>

              <div class="floatright vertical-menu">
            <div class="cart-icon">
                <?php
                // Display cart icon with item count as superscript
                $cartItemCount = getCartItemCount($cart);
                echo '<a href="carts.php">🛒';
                if ($cartItemCount > 0) {
                    echo '<sup>' . $cartItemCount . '</sup>';
                }
                echo '</a>';
                ?>
            </div>
            <div class="search-box" id="search-box">
                <form action="search.php" method="GET">
                    <input type="text" name="query" placeholder="Search...">
                    <input type="submit" value="Search">
                </form>
            </div>
            <?php if ($is_logged_in): ?>
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Sign In</a>
                <a href="create-user.php">Sign Up</a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Rest of your HTML content -->
    <div class="grid_12">
        <ul class="nav main">
            <li class="ic-dashboard"><a href="useraddpro.php"><span>SELL</span></a></li>
            <li class="ic-dashboard"><a href="shop.php"><span>BUY</span></a></li>
            <li class="ic-grid-tables"><a href="catshopname.php"><span>All Shop</span></a></li>
            <li class="ic-dashboard"><a href="categories.php"><span>Category</span></a></li>
        </ul>
    </div>
</body>
</html>
