<?php
ob_start(); // Start output buffering
include_once 'user-header.php';
include_once 'Cart.php';
include_once 'customer.php';

// Function to get session value
function getSession($key) {
    return isset($_SESSION[$key]) ? $_SESSION[$key] : null;
}

$ct = new cart();
if (isset($_GET['orderid']) && $_GET['orderid'] == 'Order') {
    $cmrId = getSession("cmrId");
    $insertOrder = $ct->orderProduct($cmrId);
    $delData = $ct->delCustomerCart();
    header("Location:success.php");
    exit(); // Add exit after header redirection
}
?>

<div class="main">
    <div class="content">
        <div class="section group">
            <div class="division">
                <table class="tblone">
                    <tr>
                        <th>No</th>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                    </tr>
                    <?php 
                    $getPro = $ct->getCartProduct();
                    $i = 0;
                    $sum = 0;
                    $qty = 0;
                    if ($getPro) {
                        while ($result = $getPro->fetch_assoc()) {
                            $i++;
                    ?>
                    <tr>
                        <td><?php echo $i;?></td>
                        <td><?php echo $result['productName']; ?></td>
                        <td>Ksh. <?php echo $result['price']; ?></td>
                        <td><?php echo $result['quantity']; ?></td>
                        <td>
                            Ksh <?php
                            $total = $result['price'] * $result['quantity'];
                            echo $total;
                            ?>
                        </td>
                    </tr>
                    <?php 
                        $qty += $result['quantity'];
                        $sum += $total;
                        } 
                    }
                    ?>    
                </table> 
                <table class="tbltwo">
                    <tr>
                        <td>Total</td>
                        <td>:</td>
                        <td>Ksh. <?php echo $sum; ?></td>
                    </tr>
                  
                  
                   
                </table>
            </div>
            <div class="division">
                <?php 
                $cmr = new Customer();
                $id = getSession("cmrId");
                $getdata = $cmr->getCustomerData($id);
                if ($getdata) {
                    while ($result = $getdata->fetch_assoc()) {
                ?>
                <table class="tblone">
                    <tr>
                        <td colspan="3"><h2>Your Delivery Details</h2></td>
                    </tr>
                    <tr>
                        <td>Full Name</td>
                        <td>:</td>
                        <td><?php echo $result['name'];?></td>
                    </tr>
                    <tr>
                        <td>Phone</td>
                        <td>:</td>
                        <td><?php echo $result['phone'];?></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td>:</td>
                        <td><?php echo $result['email'];?></td>
                    </tr>
                    <tr>
                        <td>Town Address</td>
                        <td>:</td>
                        <td><?php echo $result['address'];?></td>
                    </tr>
                
                 <tr>
                        <td>County</td>
                        <td>:</td>
                        <td><?php echo $result['country'];?></td>
                    </tr>
                
                    <tr>
                        <td></td>
                        <td></td>
                        <td><a href="editprofile.php">Update Details</a></td>
                    </tr>
                </table>
                <?php 
                    }
                } 
                ?>
            </div>
        </div>
    </div>
    <div class="ordernow"><a href="?orderid=Order">Order Now</a></div>
</div>
<?php include 'footer.php';?>

<style>
.division {
    width: 100%;
    margin-bottom: 20px;
}

.tblone, .tbltwo {
    width: 100%;
    margin: 0 auto 20px;
    border: 2px solid #ddd;
    border-collapse: collapse;
}
.tblone th, .tblone td, .tbltwo th, .tbltwo td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}
.tblone th, .tbltwo th {
    background-color: #f2f2f2;
}

@media screen and (min-width: 600px) {
    .division {
        width: 48%;
        float: left;
        margin-right: 2%;
    }
    .division:last-child {
        margin-right: 0;
    }
}

.ordernow {
    text-align: center;
    margin-top: 20px;
}
.ordernow a {
    display: inline-block;
    padding: 10px 20px;
    font-size: 16px;
    background: black;
    color: #fff;
    border-radius: 5px;
    text-decoration: none;
}
</style>

<?php
ob_end_flush(); // Flush the output buffer and send output to the browser
?>
