<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Database connection
    include_once 'config.php';
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the submitted form data
    $token = $_POST['token'];
    $pass = $_POST['password'];
    $confirmPass = $_POST['confirm_password'];

    // Validate input
    if ($pass !== $confirmPass) {
        echo "Passwords do not match";
        exit;
    }

    // Find user by token
    $stmt = $conn->prepare("SELECT * FROM adminlogin WHERE reset_token = ? AND token_expiry > NOW()");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    if (!$user) {
        echo "Invalid or expired token";
        exit;
    }

    // Update user's password
    $hashed_pass = password_hash($pass, PASSWORD_BCRYPT); // Hash the password
    $stmt = $conn->prepare("UPDATE adminlogin SET admin_pass = ?, reset_token = NULL, token_expiry = NULL WHERE reset_token = ?");
    $stmt->bind_param("ss", $hashed_pass, $token);
    if ($stmt->execute()) {
        echo "<script>alert('Password successfully reset'); window.location.href='adminlogin.php';</script>";
        exit;
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
} else if (isset($_GET['token'])) {
    // Display the reset form if token is present in URL
    $token = $_GET['token'];
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin: 10px 0 5px;
            color: #333;
        }
        input[type="password"] {
            padding: 10px;
            margin: 5px 0 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }
        input[type="submit"] {
            background: #007bff;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        input[type="submit"]:hover {
            background: #0056b3;
        }
        .message {
            text-align: center;
            color: red;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Reset Password</h2>
        <form method="post">
            <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
            <label for="password">New Password:</label>
            <input type="password" id="password" name="password" required>
            <label for="confirm_password">Confirm New Password:</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
            <input type="submit" value="Reset Password">
        </form>
        <div class="message">
        </div>
    </div>
</body>
</html>

<?php
} else {
    echo "Invalid request";
}
?>
