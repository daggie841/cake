<?php
session_start();
include_once 'admin-header.php';


// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Not logged in, redirect to login page
    header("Location: adminlogin.php");
    exit;
}

// Initialize $update_stmt
$update_stmt = null;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        include 'config.php'; // Added missing semicolon

         $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Get the submitted form data
        $email = $_POST['email'];
        $old_pass = $_POST['old_password'];
        $new_pass = $_POST['new_password'];
        $confirm_pass = $_POST['confirm_password'];

        // Check if the new password matches the confirm password
        if ($new_pass != $confirm_pass) {
            echo("<script>alert('New password and confirm password do not match.');</script>");
        } else {
            // Prepare and execute the query to check if the admin exists and old password matches
            $stmt = $conn->prepare("SELECT * FROM adminlogin WHERE admin_email = ? AND admin_pass = ?");
            $stmt->bind_param("ss", $email, $old_pass);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                // Admin exists and old password matches, update the password
                $update_stmt = $conn->prepare("UPDATE adminlogin SET admin_pass = ? WHERE admin_email = ?");
                $update_stmt->bind_param("ss", $new_pass, $email);
                $update_result = $update_stmt->execute();
                
                if ($update_result) {
                    echo "<script>alert('Password updated successfully. Please login again.');</script>";
                    // Redirect to the login page after successfully changing the password
                    header("Location: adminlogin.php");
                    exit();
                } else {
                    echo "<script>alert('Failed to update password. Please try again later.');</script>";
                }
            } else {
                // Admin does not exist or old password does not match
                echo("<script>alert('Invalid email or old password.');</script>");
            }
        }
    } catch (Exception $e) {
        echo 'Connection failed: ' . $e->getMessage();
    } finally {
        // Close the statements if they were prepared
        if (isset($stmt)) {
            $stmt->close();
        }
        if (isset($update_stmt)) {
            $update_stmt->close();
        }
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Change Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            justify-content: center;
            background-color: #f1f1f1;
        }

        .login-container {
            background-color: #fff;
            padding: 50px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .login-container h1 {
            margin-bottom: 20px;
            text-align: center;
        }

        .login-container form {
            width: 100%;
        }

        .login-container input[type="email"],
        .login-container input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .login-container input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            border: none;
            color: white;
            cursor: pointer;
            border-radius: 5px;
        }

        .login-container input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .login-container p {
            margin-top: 10px;
            text-align: center;
        }

        .login-container a {
            color: #007bff;
            text-decoration: none;
        }

        .login-container a:hover {
            text-decoration: underline;
        }

        /* Error Message Style */
        .error {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>Change Password</h1>
        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Your PHP code for password change here
        }
        ?>
        <form action="" method="POST">
            <div>
                <input type="email" name="email" placeholder="Email" required>
            </div>
            <div>
                <input type="password" name="old_password" placeholder="Old Password" required>
            </div>
            <div>
                <input type="password" name="new_password" placeholder="New Password" required>
            </div>
            <div>
                <input type="password" name="confirm_password" placeholder="Confirm New Password" required>
            </div>
            <div>
                <input type="submit" value="Change Password">
            </div>
        </form>
        <p><a href="admin_dashboard.php">Back to dashboard</a></p>
    </div>
</body>
</html>
<?php include'adminfooter.php';?>
