-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 27, 2024 at 03:35 AM
-- Server version: 5.7.23-23
-- PHP Version: 8.1.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `thmcramy_chicken`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE `adminlogin` (
  `admin_id` int(11) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_pass` int(255) NOT NULL,
  `reset_token` varchar(255) NOT NULL,
  `token_expiry` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`admin_id`, `admin_email`, `admin_pass`, `reset_token`, `token_expiry`) VALUES
(4, '2@GMAIL.COM', 123456, '5b6aafe9cb595e345fc100e9e921b977fbc7c70248175ca7e6ffc3f0120b092e', '2024-06-11 01:59:15'),
(5, 'douglasnjuguna76@gmail.com', 0, 'ef5f3356d4506b38f288cde54180f9a43d399aaacb214174b141527d3658dc87', '2024-07-10 01:11:20'),
(6, 'sikamfarms@gmail.com', 123456, '63d7587f7a4a1c0ca8f893ce95262b20a17c6d3b4ea34d4160d095b3cc2ca363', '2024-07-11 07:49:49');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brand`
--

CREATE TABLE `tbl_brand` (
  `brandId` int(11) NOT NULL,
  `brandName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `catId` int(11) NOT NULL,
  `sId` varchar(255) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `price` float(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `catId` int(11) NOT NULL,
  `catName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`catId`, `catName`) VALUES
(1, 'Hen'),
(3, 'Cocks'),
(4, 'Sikam Kienyeji eggs'),
(5, 'Dressed kienyeji chicken'),
(10, 'kienyeji chicken'),
(11, 'Sikam chick'),
(12, 'Layers'),
(13, 'Chicks'),
(14, 'Eggs');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `status` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`id`, `name`, `email`, `contact`, `message`, `status`, `date`) VALUES
(1, 'uu', 'k@gmail.com', '0765771234', 'kuku', 1, '2024-06-02 10:17:03'),
(2, 'bb', 'g@gmail.com', '0987654321', 'dtyuiop', 1, '2024-05-20 09:38:28'),
(3, 'erty', 'd@gmail.com', '1234567890', 'dfgh', 1, '2024-05-31 23:19:47'),
(4, 'erty', 'd@gmail.com', '1234567890', 'dfgh', 1, '2024-05-23 23:00:29'),
(5, 'EEE', '2@GMAIL.COM', '0987654321', 'NICE', 1, '2024-06-02 12:01:11');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(30) NOT NULL,
  `country` varchar(30) NOT NULL,
  `zip` varchar(30) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pass` varchar(32) NOT NULL,
  `reset_token` varchar(255) NOT NULL,
  `token_expiry` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `address`, `city`, `country`, `zip`, `phone`, `email`, `pass`, `reset_token`, `token_expiry`) VALUES
(4, 'jonson kinyajui', 'Nyamakema', 'kenya', 'Migori', 'kenya', '1234567890', '1@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', '0000-00-00 00:00:00'),
(8, 'Antony', 'Street/road:Mpeketoni', 'Mpeketoni', 'Kenya', '80503', '0758002042', 'tonylvan77@gmail.com', 'ea3f030095881c6522ab679c4d332a44', '', '0000-00-00 00:00:00'),
(9, 'kamau', 'keroka', '', 'migori', '', '0712345678', 'kamau@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', '0000-00-00 00:00:00'),
(10, 'k', 'karachuonyo', '', 'homabay', '', '1234567890', 'kk@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', '0000-00-00 00:00:00'),
(11, 'koko', 'mpk', '', 'lamu', '', '0712343212', 'koko@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', '0000-00-00 00:00:00'),
(12, 'Boniface onyeso', 'Nyamasaria', '', 'Nyamira', '', '0768466612', 'Bo@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', '0000-00-00 00:00:00'),
(13, 'Tony Aluso', '340', '', 'Siaya', '', '0740193583', 'alusotony@gmail.com', '7b695c9e72b3d5fd28d22bdf7e3d79f0', '', '0000-00-00 00:00:00'),
(14, 'Omondi', 'KISUMU', '', 'Kenya', '', '0758002042', 'lva@gmail.com', 'ea3f030095881c6522ab679c4d332a44', '', '0000-00-00 00:00:00'),
(15, 'Ken wamakua', 'Shinyalu', '', 'Kakamega', '', '0768466613', 'douglasnjuguna74@gmail.com', '$2y$10$MJqJIh3QNgFHsY77xo722uZqx', '76e0333699ff0c3efdd52109892b314715f4150a3feaf05e4635e7f9f7ef2f78', '2024-07-11 07:58:25'),
(16, 'gfgfg', 'dgdfsfs', '', 'Kenya', '', '0898655656', 'reretrt@yahoo.com', 'e10adc3949ba59abbe56e057f20f883e', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(11) NOT NULL,
  `cmrId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` float(10,2) NOT NULL,
  `image` varchar(255) NOT NULL,
  `date` datetime NOT NULL,
  `status` int(11) NOT NULL,
  `pstatus` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `cmrId`, `productId`, `productName`, `quantity`, `price`, `image`, `date`, `status`, `pstatus`) VALUES
(1, 4, 108, 'Original kienyeji', 14, 11200.00, '14.jpeg', '2024-07-20 17:47:46', 2, 0),
(2, 4, 114, 'Egg', 4, 60.00, '17.jpg', '2024-07-20 17:47:46', 2, 0),
(3, 4, 129, '1 weeks old chicks', 15, 2100.00, '8.jpeg', '2024-07-26 22:50:23', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `catName` varchar(255) NOT NULL,
  `catId` int(11) NOT NULL,
  `brandId` int(11) NOT NULL,
  `body` text NOT NULL,
  `price` float(10,2) NOT NULL,
  `image` varchar(255) NOT NULL,
  `type` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`productId`, `productName`, `catName`, `catId`, `brandId`, `body`, `price`, `image`, `type`) VALUES
(126, 'Eggs For Hatching', 'Eggs', 14, 0, ' Priced at just 30/= per egg or 900/= per crate,.Our premium kienyeji hatching eggs, meticulously selected for their fertility and quality. Each egg is sourced from well-cared-for kienyeji chickens, ensuring a high hatch rate and healthy chicks. Priced at just 30/= per egg or 900/= per crate, these eggs offer exceptional value for poultry farmers and enthusiasts alike. Ideal for those looking to expand their flock with robust, high-quality birds, our kienyeji hatching eggs promise reliable results and strong, thriving chicks. Invest in the best for your poultry needs and watch your flock flourish with our superior hatching eggs.', 30.00, 'image/00130822-One-White-Egg-with-Two-Brown-Eggs.jpg', 0),
(127, 'Eggs hatching services', 'Chicks', 13, 0, 'Within 48 hours your eggs will be turned in chicks and ready for collection. At our hatchery, we offer a convenient egg-to-chick service. Bring us your eggs, and we\'ll hatch them into chicks for you. We specialize in hatching fresh eggs that are seven days old or younger, with incubation scheduled every Friday. Please collect your chicks within 48 hours of hatching. Our pricing is as follows: Chicken eggs are incubated at 35/= each, with an additional 10/= per chick hatched; Guinea fowl eggs are incubated at 40/= each, with 10/= per keet hatched; Turkey eggs are incubated at 90/= each, with 10/= per poult hatched. prices differ\r\nExperience hassle-free hatching with us!', 45.00, 'hatched egg.jpg', 0),
(128, 'Day old chicks', 'Sikam chick\r\n\r\n', 11, 0, 'Priced at just 110/= per chick. Minimum order of 20 chicks. Our day-old chicks come from our well-managed, improved Kienyeji parent stock, ensuring robust health and vitality. Priced at just 110/= per chick, these healthy chicks are an excellent investment for any poultry farmer. We require a minimum order of 20 chicks to maintain optimal quality and consistency. Each chick benefits from our dedicated care and high standards, giving you the confidence of strong, thriving poultry right from the start. Start your flock with our premium Kienyeji chicks and experience the difference that quality breeding and management make in your poultry farming success.', 110.00, '1 day.jpg', 0),
(129, '1 weeks old chicks', 'Sikam chick', 11, 0, 'Our chick has received its first dose of the Newcastle Disease (NCD) vaccine,.Our one-week-old chicks, sourced from our top-quality parent stock, are ready to thrive in your care. Each chick has received its first dose of the Newcastle Disease (NCD) vaccine, ensuring they start life with strong health protection. Priced at just 140/= per chick, they offer exceptional value for those looking to expand their flock. We require a minimum order of 20 chicks to ensure optimal health and consistency. Invest in these healthy, vaccinated chicks and enjoy the peace of mind that comes with quality care from the outset.', 140.00, '8.jpeg', 0),
(130, '2 weeks old chicks', 'Chicks', 13, 0, 'All chicks have received its first doses of the Newcastle Disease (NCD) and Gumboro vaccines,.Discover our healthy, two-week-old chicks, sourced from our robust parent stock. Each chick has received its first doses of the Newcastle Disease (NCD) and Gumboro vaccines, ensuring strong immunity and optimal health. Priced at just 180/= per chick, these vaccinated chicks offer excellent value for your investment. Please note that we maintain a minimum order requirement of 20 chicks to ensure you receive a sufficient and manageable flock. Invest in the future of your poultry farming with our carefully bred and well-protected chicks, ready to grow into healthy, productive birds.', 180.00, 'image/IMG_5810-683x1024.png', 0),
(131, '3 weeks old chicks', 'Sikam chick\r\n', 11, 0, 'We offer healthy three-week-old chicks sourced from our robust parent stock. Each chick has received the first and second doses of the Newcastle Disease (NCD) vaccine and the first dose of the Gumboro vaccine, ensuring strong immunity and excellent health. These chicks are available at a price of 240/= each, with a minimum order requirement of 20 chicks. Ideal for poultry farmers looking to start or expand their flock with disease-resistant, well-vaccinated chicks. Secure your order today to ensure you receive high-quality chicks that promise healthy growth and productivity.', 240.00, 'image/images.jpg', 0),
(132, '4 weeks old chicks', 'Sikam chick', 11, 0, 'Our healthy 4-week-old chicks, sourced from our premium parent stock, have received their first and second doses of both Newcastle Disease (NCD) and Gumboro vaccines. These vaccinations ensure robust immunity and optimal growth. Each chick is available for 300/=, with a minimum order requirement of 20 chicks. Our commitment to quality and health ensures that you receive strong and vibrant chicks, ready to thrive and contribute to your poultry farming success. Order now to secure these well-cared-for chicks for your flock.', 296.00, '3week.jpg', 0),
(133, 'Live kienyeji chicken', 'Hen', 1, 0, 'We offer our live Kienyeji hens at an affordable price of 1,000/= each,\r\nExperience the unique flavor and health benefits of our healthy and tasty live Kienyeji chickens. Raised naturally in open environments, our chickens offer a rich and authentic taste that sets them apart from conventional poultry. Whether you\'re looking for a hen or a cock, our Kienyeji chickens provide a wholesome and nutritious addition to your meals.\r\n\r\nQuality and Health Benefits\r\n\r\nOur Kienyeji chickens are raised without the use of antibiotics or growth hormones, ensuring that you receive only the purest and most natural poultry. These chickens are allowed to roam freely, forage, and graze, which contributes to their leaner meat and higher nutrient content. The free-range lifestyle not only promotes the well-being of the chickens but also enhances the flavor and texture of the meat, making it tender and succulent.\r\n\r\nPricing and Availability\r\n\r\nWe offer our live Kienyeji hens at an affordable price of 1,000/= each, and cocks at 1,200/= each. Each bird weighs between 1 to 1.2 kilograms, providing an ideal size for family meals or special occasions. The pricing reflects the high quality and care that goes into raising each chicken, ensuring that you get the best value for your money.\r\n\r\nNutritional Value\r\n\r\nKienyeji chickens are renowned for their superior nutritional profile. They are lower in fat compared to commercially raised chickens, making them a healthier option for those conscious of their diet. The meat is rich in protein, essential vitamins, and minerals, contributing to a balanced and nutritious diet. Consuming Kienyeji chicken can support muscle growth, improve immune function, and provide the energy needed for daily activities.\r\n\r\nCooking and Culinary Uses\r\n\r\nThe robust flavor of Kienyeji chicken makes it a versatile ingredient in various culinary dishes. Whether you prefer traditional stews, grilled dishes, or baked recipes, Kienyeji chicken adds a distinct taste that enhances any meal. The meat\'s natural flavor pairs well with a wide range of spices and herbs, allowing you to experiment with different cooking methods and recipes.\r\n\r\nSustainable and Ethical Farming Practices\r\n\r\nBy choosing our Kienyeji chickens, you are supporting sustainable and ethical farming practices. We prioritize the welfare of our chickens, providing them with ample space to roam and access to a natural diet. This approach not only benefits the chickens but also ensures that you receive a high-quality product that you can feel good about consuming.\r\n\r\nConclusion\r\n\r\nOur healthy and tasty live Kienyeji chickens offer a perfect blend of flavor, nutrition, and ethical farming practices. With hens priced at 1,000/= and cocks at 1,200/=, each weighing between 1 to 1.2 kilograms, you are guaranteed a superior product that is both delicious and beneficial to your health. Experience the difference that naturally raised Kienyeji chickens can make in your meals and enjoy the rich, authentic taste they bring to your table.', 1000.00, '14.jpeg', 0),
(134, 'Dressed kienyeji chicken', 'Hen', 1, 0, 'Healthy and Tasty Dressed Kienyeji Chicken - 500/= per Kg\r\n\r\nIndulge in the rich, authentic flavors of our dressed Kienyeji chicken, meticulously prepared to offer both health benefits and gastronomic delight. Priced at an affordable 500 Kenyan Shillings per kilogram, our Kienyeji chicken stands out as a premium choice for those seeking wholesome, delicious, and naturally raised poultry.\r\n\r\nWhy Choose Kienyeji Chicken?\r\n\r\nKienyeji chicken, also known as indigenous or free-range chicken, is a breed renowned for its superior quality and natural rearing process. Unlike commercially bred chickens, Kienyeji chickens are raised in an open environment, allowing them to forage freely and enjoy a diet rich in natural nutrients. This method of farming ensures that the chickens develop robust health, with meat that is not only flavorful but also packed with essential nutrients.\r\n\r\nHealth Benefits\r\n\r\nOne of the key advantages of Kienyeji chicken is its nutritional profile. It is leaner than its commercially bred counterparts, making it an excellent choice for health-conscious individuals. The meat is rich in protein, essential for muscle growth and repair, and contains lower fat content, which is beneficial for heart health. Additionally, Kienyeji chicken is free from antibiotics and growth hormones, ensuring that you consume pure, unadulterated poultry.\r\n\r\nTantalizing Taste\r\n\r\nThe taste of Kienyeji chicken is distinctly superior, characterized by its firm texture and rich, earthy flavor. This is attributed to the chicken’s natural diet and active lifestyle, which contributes to the development of its unique taste profile. Whether grilled, roasted, stewed, or fried, Kienyeji chicken retains its delicious flavor and remains tender and juicy, making it a versatile ingredient for various culinary creations.\r\n\r\nEthical and Sustainable Farming\r\n\r\nOur Kienyeji chickens are raised with a strong commitment to ethical and sustainable farming practices. We prioritize the welfare of our chickens, providing them with a stress-free environment that allows them to thrive naturally. By choosing our Kienyeji chicken, you are supporting sustainable agriculture and contributing to the well-being of the environment.\r\n\r\nValue for Money\r\n\r\nAt 500 Kenyan Shillings per kilogram, our dressed Kienyeji chicken offers exceptional value for money. You are investing in high-quality poultry that delivers on both health and taste. Each kilogram of our dressed chicken is meticulously cleaned and prepared, ready to be cooked into your favorite dishes.\r\n\r\nIn conclusion, our healthy and tasty dressed Kienyeji chicken is an excellent choice for those who appreciate quality, flavor, and nutrition. Priced affordably, it promises a delightful culinary experience while supporting ethical farming practices. Enjoy the best of both worlds with our premium Kienyeji chicken, and elevate your meals to new heights of deliciousness and healthiness.\r\n\r\n\r\n\r\n\r\n\r\n\r\n', 500.00, '7.jpeg', 0),
(135, 'Sikam Kienyeji eggs', 'Sikam Kienyeji eggs', 4, 0, ' Priced at 20/= per egg or 550/= for a 30-egg crate.Healthy deep “orange yolked” eggs from Sikam Farms offer a nutritious and vibrant addition to your diet. Priced at 20/= per egg or 550/= for a 30-egg crate, these eggs stand out not only for their rich color but also for their superior quality and taste.\r\n\r\nSikam Farms, renowned for its dedication to sustainable and ethical farming practices, ensures that each egg is produced under the highest standards of animal welfare. The hens at Sikam Farms are raised in a free-range environment, allowing them to roam and forage naturally. This natural lifestyle contributes to the exceptional nutritional profile of the eggs, which are rich in essential vitamins, minerals, and omega-3 fatty acids.\r\n\r\nThe deep orange yolk is a hallmark of the high-quality feed and care the hens receive. Unlike pale, factory-farmed eggs, Sikam Farms’ eggs have a yolk color that indicates a diet rich in natural carotenoids. These carotenoids, derived from a diet of greens, insects, and grains, not only enhance the yolk’s color but also boost its nutritional value. Carotenoids are antioxidants that support eye health and immune function, making these eggs a particularly healthful choice.\r\n\r\nIn addition to their nutritional benefits, Sikam Farms’ eggs are known for their superior taste and texture. The vibrant yolk provides a richer, creamier flavor, making them a favorite among chefs and home cooks alike. Whether you’re frying, poaching, scrambling, or baking, these eggs elevate any dish with their distinct taste and quality.\r\n\r\nPurchasing from Sikam Farms also means supporting local agriculture and sustainable farming practices. The farm is committed to reducing its environmental footprint through responsible farming techniques and renewable energy sources. By choosing Sikam Farms’ eggs, you’re not only nourishing your body with wholesome food but also contributing to a healthier planet.\r\n\r\nEach egg is carefully collected, cleaned, and inspected to ensure it meets the farm’s stringent quality standards. The attention to detail in every step of the process guarantees that you receive only the best eggs, free from antibiotics and hormones.\r\n\r\nThe affordable pricing of 20/= per egg and 550/= per 30-egg crate offers excellent value for such high-quality produce. Whether you’re feeding a family or catering a special event, Sikam Farms’ eggs provide a reliable and delicious option.\r\n\r\nIn summary, Sikam Farms’ healthy deep “orange yolked” eggs are a premium product that combines exceptional nutrition, superior taste, and ethical farming practices. By choosing these eggs, you’re making a positive impact on your health and the environment, all while enjoying the unparalleled quality and flavor that only Sikam Farms can offer.\r\n\r\n\r\n\r\n\r\n\r\n\r\n', 20.00, 'eggs.png', 0),
(136, 'Brown & White', 'Sikam Kienyeji eggs', 4, 0, 'Our eggs are affordably priced at 17/= per egg and 450/= for a crate of 30 eggs.\r\n\r\nAt Sikam Farms, we take pride in providing the highest quality eggs to our valued customers. Our healthy white and brown eggs are a staple in many households, known for their superior taste, nutritional value, and ethical sourcing. Carefully raised in a free-range environment, our chickens are fed a natural, balanced diet, ensuring that each egg is packed with essential nutrients.\r\n\r\nFreshness and Quality\r\nOur commitment to freshness is unwavering. Each egg is carefully collected, cleaned, and inspected to meet stringent quality standards before it reaches your hands. The result is a product that boasts a rich flavor, vibrant yolks, and firm whites, perfect for a wide range of culinary applications. Whether you\'re baking, scrambling, or making an omelette, our eggs are sure to enhance your dishes.\r\n\r\nNutritional Benefits\r\nEggs are a powerhouse of nutrition, and our healthy white and brown eggs are no exception. They are an excellent source of high-quality protein, essential vitamins, and minerals. Each egg contains vital nutrients such as vitamin A, vitamin D, vitamin B12, riboflavin, and selenium. These nutrients play a crucial role in maintaining good health, supporting brain function, and boosting the immune system. Additionally, the presence of choline in eggs aids in brain development and function, making them a perfect addition to a balanced diet.\r\n\r\nEthical and Sustainable Farming\r\nSikam Farms is dedicated to ethical farming practices. Our chickens are raised in a humane environment, with ample space to roam and express natural behaviors. We avoid the use of antibiotics and hormones, ensuring that our eggs are not only healthy but also ethically produced. Sustainability is at the core of our operations, and we continuously strive to minimize our environmental footprint through eco-friendly practices.\r\n\r\nAffordable Pricing\r\nWe believe that high-quality, nutritious food should be accessible to everyone. Our eggs are affordably priced at 17/= per egg and 450/= for a crate of 30 eggs. This competitive pricing ensures that you can enjoy the benefits of fresh, healthy eggs without breaking the bank.\r\n\r\nCustomer Satisfaction\r\nAt Sikam Farms, customer satisfaction is our top priority. We are committed to providing exceptional service and ensuring that our customers are always happy with their purchases. Our eggs are packed with care and delivered promptly to maintain their freshness and quality.\r\n\r\nIn conclusion, Sikam Farms\' healthy white and brown eggs offer a perfect blend of taste, nutrition, and ethical production. By choosing our eggs, you are not only nourishing your body with high-quality protein and essential nutrients but also supporting sustainable and humane farming practices. Enjoy the best that nature has to offer with Sikam Farms\' eggs.', 17.00, '17.jpg', 0),
(137, 'Kienyeji cock', 'Cocks', 3, 0, 'Our Kienyeji cock that weigh from 2.5 to 4kg\r\n\r\nA Kenyan Kienyeji cock within the price range of 1000 to 2000 Ksh typically exhibits several notable features. Here is a detailed description:\r\n\r\nPhysical Characteristics:\r\nSize and Build:\r\n\r\nMedium to Large Size: Kienyeji cocks are generally medium to large in size, with a robust and muscular build.\r\nWeight: They usually weigh between 2.5 to 4 kg.\r\nFeathers:\r\n\r\nColor: The feather color varies widely, including combinations of black, brown, white, and red. Some may have a glossy sheen.\r\nTexture: Their feathers are generally thick and dense, providing good protection.\r\nComb and Wattle:\r\n\r\nComb: They have a prominent comb, usually red, which can be single or slightly floppy.\r\nWattle: The wattle is also well-developed and red, complementing the comb.\r\nBeak and Legs:\r\n\r\nBeak: The beak is strong and slightly curved, usually yellow or horn-colored.\r\nLegs: Their legs are sturdy and well-formed, often yellow or gray, with sharp spurs that are more pronounced in mature cocks.\r\nBehavior and Temperament:\r\nActive and Alert: Kienyeji cocks are known for their alertness and active behavior. They are excellent at foraging and are generally more resilient to diseases compared to commercial breeds.\r\nTerritorial: They can be territorial and may exhibit protective behavior towards their flock, making them good guardians.\r\nCrow: Their crow is loud and distinctive, often used to assert dominance and mark territory.\r\nAdaptability:\r\nHardiness: Kienyeji cocks are well-adapted to local conditions. They thrive in free-range environments and are capable of foraging for their own food.\r\nClimate Resilience: They are resilient to various weather conditions, including the hot and sometimes harsh climates typical of Kenya.\r\nEconomic Value:\r\nPrice Range: The price range of 1000 to 2000 Ksh makes them an affordable option for small-scale farmers and households.\r\nEgg Fertility: They have good fertility rates, making them valuable for breeding purposes to produce high-quality Kienyeji chicks.\r\nMarket Demand:\r\nPreference: There is a high preference for Kienyeji chickens due to their flavor and texture, which is considered superior to commercial broilers.\r\nCultural Significance: They hold cultural significance in many Kenyan communities and are often used in traditional ceremonies and celebrations.\r\nOverall:\r\nA Kienyeji cock within this price range offers a combination of resilience, good breeding potential, and suitability for free-range farming, making it a practical and valuable addition to any flock.', 1200.00, 'image/13.jpg', 0),
(138, 'Pure white hen', 'Eggs', 12, 0, 'A pure white hen that falls within a price range of 500 to 1,000 KSH and lays an impressive number of eggs would likely be a high-yielding layer breed. Here’s a description of such a hen:\r\n\r\nCharacteristics\r\nAppearance: The hen has a pure white plumage, which makes it visually striking. Its feathers are clean and bright, reflecting good health and care.\r\nSize: Medium to large size, with a robust and well-proportioned body. It typically has a good frame and healthy physical build.\r\nEgg Production: This hen is known for its impressive egg-laying capabilities. It can produce between 250 to 320 eggs per year, depending on its age and management practices. The eggs are usually medium to large in size and have a consistent quality.\r\nTemperament: Generally, this breed has a calm and friendly disposition, making it easy to manage in a flock setting.\r\nHealth: The hen is resilient and adaptable to different environments. Proper care includes regular vaccinations, a balanced diet, and good housing to maintain its health and productivity.\r\nPrice Range\r\n500 to 1,000 KSH: This price range suggests that the hen is reasonably priced, likely due to its high productivity and good health. The price may vary based on the breeder, location, and specific traits of the hen.\r\nAdditional Considerations\r\nHousing: Adequate housing with proper ventilation and space is essential for maximizing egg production and ensuring the hen\'s well-being.\r\nDiet: A balanced feed that includes protein, vitamins, and minerals is crucial for optimal egg production.\r\nCare: Regular health checks and good hygiene practices are important to prevent diseases and ensure high egg yield.\r\nThis description should help you understand what to look for in a pure white hen within your specified price range and its potential for egg production.', 700.00, '5.jpeg', 0),
(139, 'Free Range', 'Hen', 10, 0, 'We offer our Kienyeji hens at an affordable price of 1,000 to 2,000/= each,\r\nExperience the unique flavor and health benefits of our healthy and tasty live Kienyeji chickens. Raised naturally in open environments, our chickens offer a rich and authentic taste that sets them apart from conventional poultry. Whether you\'re looking for a hen or a cock, our Kienyeji chickens provide a wholesome and nutritious addition to your meals.\r\n\r\nQuality and Health Benefits\r\n\r\nOur Kienyeji chickens are raised without the use of antibiotics or growth hormones, ensuring that you receive only the purest and most natural poultry. These chickens are allowed to roam freely, forage, and graze, which contributes to their leaner meat and higher nutrient content. The free-range lifestyle not only promotes the well-being of the chickens but also enhances the flavor and texture of the meat, making it tender and succulent.\r\n\r\nPricing and Availability\r\n\r\nWe offer our live Kienyeji hens at an affordable price of 1,000/= each, and cocks at 1,200/= each. Each bird weighs between 1 to 1.2 kilograms, providing an ideal size for family meals or special occasions. The pricing reflects the high quality and care that goes into raising each chicken, ensuring that you get the best value for your money.\r\n\r\nNutritional Value\r\n\r\nKienyeji chickens are renowned for their superior nutritional profile. They are lower in fat compared to commercially raised chickens, making them a healthier option for those conscious of their diet. The meat is rich in protein, essential vitamins, and minerals, contributing to a balanced and nutritious diet. Consuming Kienyeji chicken can support muscle growth, improve immune function, and provide the energy needed for daily activities.\r\n\r\nCooking and Culinary Uses\r\n\r\nThe robust flavor of Kienyeji chicken makes it a versatile ingredient in various culinary dishes. Whether you prefer traditional stews, grilled dishes, or baked recipes, Kienyeji chicken adds a distinct taste that enhances any meal. The meat\'s natural flavor pairs well with a wide range of spices and herbs, allowing you to experiment with different cooking methods and recipes.\r\n\r\nSustainable and Ethical Farming Practices\r\n\r\nBy choosing our Kienyeji chickens, you are supporting sustainable and ethical farming practices. We prioritize the welfare of our chickens, providing them with ample space to roam and access to a natural diet. This approach not only benefits the chickens but also ensures that you receive a high-quality product that you can feel good about consuming.\r\n\r\nConclusion\r\n\r\nOur healthy and tasty live Kienyeji chickens offer a perfect blend of flavor, nutrition, and ethical farming practices. With hens priced at 1,000/= and cocks at 1,200/=, each weighing between 1 to 1.2 kilograms, you are guaranteed a superior product that is both delicious and beneficial to your health. Experience the difference that naturally raised Kienyeji chickens can make in your meals and enjoy the rich, authentic taste they bring to your table.', 1199.00, 'image/11.jpeg', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminlogin`
--
ALTER TABLE `adminlogin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  ADD PRIMARY KEY (`brandId`);

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`catId`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`catId`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`productId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminlogin`
--
ALTER TABLE `adminlogin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  MODIFY `brandId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `catId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=232;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `catId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
