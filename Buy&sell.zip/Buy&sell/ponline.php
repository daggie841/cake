<?php

ob_start();
include 'user-header.php';
include 'mpesa.php'; // Include the M-Pesa
include 'Cart.php';
include 'customer.php';

// Function to get session value
function getSession($key) {
    return isset($_SESSION[$key]) ? $_SESSION[$key] : null;
}

// Function to initiate M-Pesa payment
function initiateMpesaPayment($amount, $phone, $orderId) {
    $url = 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';
    $accessToken = getAccessToken(); // Fetch the access token
    $timestamp = date('YmdHis');
    $password = base64_encode(SHORTCODE . PASSKEY . $timestamp);

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
        'Authorization: Bearer ' . $accessToken,
        'Content-Type: application/json'
    ));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode([
        'BusinessShortCode' => 174379, // Use the defined shortcode
        'Password' => $password,
        'Timestamp' => $timestamp,
        'TransactionType' => 'CustomerPayBillOnline',
        'Amount' => $amount,
        'PartyA' => $phone,
        'PartyB' => 174379, // Use the defined shortcode or relevant value
        'PhoneNumber' => $phone,
        'CallBackURL' => CALLBACK_URL,
        'AccountReference' => 'ORDER' . $orderId,
        'TransactionDesc' => 'Payment for Order #' . $orderId
    ]));

    $response = curl_exec($curl);
    
    // Check for cURL errors
    if (curl_errno($curl)) {
        $error_msg = curl_error($curl);
        curl_close($curl);
        return ["error" => "cURL error: $error_msg"];
    }
    
    curl_close($curl);

    return json_decode($response, true);
}

$ct = new Cart();
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['orderid']) && $_POST['orderid'] == 'Order') {
    $cmrId = getSession("cmrId");
    $getPro = $ct->getCartProduct();
    $sum = 0;
    if ($getPro) {
        while ($result = $getPro->fetch_assoc()) {
            $total = $result['price'] * $result['quantity'];
            $sum += $total;
        }
    }
    $phone = $_POST['phone'];
    $orderId = uniqid();
    $response = initiateMpesaPayment($sum, $phone, $orderId);
    
    if (isset($response['ResponseCode']) && $response['ResponseCode'] == '0') {
        echo "Payment initiated successfully. Check your phone to complete the payment.";
    } else {
        echo "Payment initiation failed: " . (isset($response['errorMessage']) ? $response['errorMessage'] : 'Unknown error');
    }
    exit();
}

?>

<div class="main">
    <div class="content">
        <div class="section group">
            <div class="division">
                <table class="tblone">
                    <!-- Existing table content -->
                    <tr>
                        <th>No</th>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                    </tr>
                    <?php 
                    $getPro = $ct->getCartProduct();
                    $i = 0;
                    $sum = 0;
                    $qty = 0;
                    if ($getPro) {
                        while ($result = $getPro->fetch_assoc()) {
                            $i++;
                    ?>
                    <tr>
                        <td><?php echo $i;?></td>
                        <td><?php echo $result['productName']; ?></td>
                        <td>Ksh. <?php echo $result['price']; ?></td>
                        <td><?php echo $result['quantity']; ?></td>
                        <td>
                            Ksh <?php
                            $total = $result['price'] * $result['quantity'];
                            echo $total;
                            ?>
                        </td>
                    </tr>
                    <?php 
                        $qty += $result['quantity'];
                        $sum += $total;
                        } 
                    }
                    ?>    
                </table> 
                <table class="tbltwo">
                    <tr>
                        <td>Sub Total</td>
                        <td>:</td>
                        <td>Ksh. <?php echo $sum; ?></td>
                    </tr>
                </table>
            </div>
            <div class="division">
                <?php 
                $cmr = new Customer();
                $id = getSession("cmrId");
                $getdata = $cmr->getCustomerData($id);
                if ($getdata) {
                    while ($result = $getdata->fetch_assoc()) {
                ?>
                <table class="tblone">
                    <tr>
                        <td colspan="3"><h2>Your Delivery Details</h2></td>
                    </tr>
                    <tr>
                        <td>Full Name</td>
                        <td>:</td>
                        <td><?php echo $result['name'];?></td>
                    </tr>
                    <tr>
                        <td>Phone</td>
                        <td>:</td>
                        <td><?php echo $result['phone'];?></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td>:</td>
                        <td><?php echo $result['email'];?></td>
                    </tr>
                    <tr>
                        <td>Town Address</td>
                        <td>:</td>
                        <td><?php echo $result['address'];?></td>
                    </tr>
                     <tr>
                         <td>County</td>
                        <td>:</td>
                        <td><?php echo $result['country'];?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td><a href="editprofile.php">Update Details</a></td>
                    </tr>
                </table>
                <?php 
                    }
                } 
                ?>
            </div>
        </div>
    </div>
    <form method="post" action="">
        <label for="phone">Phone Number:</label>
        <input type="text" name="phone" id="phone" required>
        <div class="ordernow">
            <button type="submit" name="orderid" value="Order">Order Now</button>
        </div>
    </form>
</div>
<?php include 'footer.php'; ?>

<style>
.division {
    width: 100%;
    margin-bottom: 20px;
}

.tblone, .tbltwo {
    width: 100%;
    margin: 0 auto 20px;
    border: 2px solid #ddd;
    border-collapse: collapse;
}
.tblone th, .tblone td, .tbltwo th, .tbltwo td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}
.tblone th, .tbltwo th {
    background-color: #f2f2f2;
}

@media screen and (min-width: 600px) {
    .division {
        width: 48%;
        float: left;
        margin-right: 2%;
    }
    .division:last-child {
        margin-right: 0;
    }
}

.ordernow {
    text-align: center;
    margin-top: 20px;
}
.ordernow button {
    display: inline-block;
    padding: 10px 20px;
    font-size: 16px;
    background: black;
    color: #fff;
    border-radius: 5px;
    text-decoration: none;
    border: none;
}
</style>

<?php
ob_end_flush(); // Flush the output buffer and send output to the browser
?>
