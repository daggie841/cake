<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'user-header.php';
include 'Product.php'; 
include_once 'Formate.php'; 
include_once 'Cart.php';  
include_once 'Category.php';

// Instantiate Cart class
$ct = new Cart();  

if (isset($_GET['proid'])) {
    $id = preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['proid']);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    $quantity = $_POST['quantity'];
    $addCart = $ct->addToCart($quantity, $id);
}
?>

<style>
    .mybutton {
        width: 100px;
        float: left;
        margin-right: 50px;
        border-radius:10px;
    }
   
    .content {
        max-width: 1200px;
        margin: auto;
    }
    .section {
        display: flex;
        flex-wrap: wrap;
    }
    .cont-desc {
        flex: 1 1 60%;
        padding: 10px;
        box-sizing: border-box;
    }
    .grid.images_3_of_2 {
        flex: 1  40%;
        border-radius:10px;
        padding: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .grid.images_3_of_2 img {
        max-width: 100%;
        border-radius:10px;
        height: auto;
    }
    .desc {
        padding: 5px;
        box-sizing: border-box;
    }
    .desc h2 {
        font-size: 14px;
        margin-bottom: 5px;
    }
    .price {
        margin-bottom: 5px;
    }
    .price p {
        font-size: 14px;
    }
    .price span {
        font-weight: bold;
        color: green;
    }
    .add-cart {
        margin-bottom: 20px;
    }
    .add-cart form {
        display: flex;
        align-items: center;
    }
    .buyfield {
        width: 50px;
        padding: 5px;
        margin-right: 10px;
    }
    .buysubmit {
        padding: 10px 20px;
        background-color: orange;
        border-radius:20px;
        font-weight: bold;
        color: black;
        border: none;
        cursor: pointer;
        transition: background-color 0.3s;
    }
    .buysubmit:hover {
        background-color: #218838;
    }
    .product-desc {
        margin-top: 30px;
    }
    .product-desc h2 {
        font-size: 24px;
        margin-bottom: 20px;
    }
    .product-desc p {
        font-size: 16px;
        line-height: 1.5;
        color: #333;
    }
    .message {
        color: red;
        font-size: 18px;
        margin-bottom: 20px;
    }
</style>

<div class="main">
    <div class="content">
        <div class="section group">
            <div class="cont-desc">
                <?php 
                $pd = new Product();
                $getpd = $pd->getProductById($id); 
                if ($getpd && $getpd->num_rows > 0) {
                    while ($result = $getpd->fetch_assoc()) { 
                ?>            
                    <div class="grid images_3_of_2">
                        <img src="<?php echo $result['image'] ;?>" class="product-image" alt="<?php echo htmlspecialchars($result['productName']); ?>">
                    </div>
                    <div class="desc">
                        <h2><?php echo htmlspecialchars($result['productName']); ?></h2>                
                        <div class="price">
                            <p>Price: <span>Ksh. <?php echo htmlspecialchars($result['price']); ?></span></p>
                            <p>Phone number: <span> <?php echo htmlspecialchars($result['phone']); ?></span></p>
                            <p>Category: <span><?php echo htmlspecialchars($result['catName'] ?? 'N/A'); ?></span></p>
                            <p>Shop: <span><?php echo htmlspecialchars($result['shopname'] ?? 'N/A'); ?></span></p>
                        </div>
                        <div class="add-cart">
                            <form action="" method="post">
                                <input type="number" class="buyfield" name="quantity" value="1" min="1"/>
                                <input type="submit" class="buysubmit" name="submit" value="AddTo Cart"/>
                            </form>                
                        </div>
                        <div class="message">
                            <?php 
                            if (isset($addCart)) {
                                echo $addCart;
                            }
                            ?>
                        </div>
                        <?php 
                        $login = $_SESSION["cuslogin"] ?? false;
                        if ($login == true) {
                        ?>
                        <div class="add-cart">
                            <div class="mybutton">
                                <form action="" method="post">
                                    <input type="hidden" class="buyfield" name="productId" value="<?php echo htmlspecialchars($result['productId']); ?>"/>
                                </form>    
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                    <div class="product-desc">
                        <h2>Product Details</h2>
                        <p><?php echo nl2br(htmlspecialchars($result['body'])); ?></p>
                    </div>
                <?php 
                    } 
                } 
                ?>
            </div>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>
