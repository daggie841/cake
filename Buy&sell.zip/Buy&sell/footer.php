<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
        }

        .main-content {
            flex: 1;
        }

        .footer {
            background: #333;
            color: #fff;
            padding: 10px 0;
        }

        .footer .wrapper {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .footer h4 {
            margin-bottom: 5px;
            font-size: 18px;
            font-weight: bold;
        }

        .footer ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .footer ul li {
            margin-bottom: 5px;
        }

        .footer ul li a {
            color: #bbb;
            text-decoration: none;
        }

        .footer ul li a:hover {
            text-decoration: underline;
        }

        .footer .social-icons ul {
            display: flex;
            gap: 10px;
        }

        .footer .social-icons ul li {
             flex: 1;
            display: inline-block;
        }

        .footer .social-icons ul li a {
            color: #fff;
            font-size: 24px;
            transition: color 0.3s ease;
        }

        .footer .social-icons ul li a:hover {
            color: deeppink;
        }

        .section.group {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }

        .col_1_of_4 {
            flex: 1;
            min-width: 200px;
        }

        @media (max-width: 768px) {
            .section.group {
                flex-direction: column;
            }
        }

        .copy_right {
            text-align: center;
            margin-top: 5px;
            font-size: 14px;
            color: #bbb;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="main-content">
        <!-- Main content goes here -->
    </div>
    <div class="footer">
        <div class="wrapper">    
            <div class="section group">
                <div class="col_1_of_4 span_1_of_4">
                    <h4>Information</h4>
                    <ul>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="Policies.php">Privacy Policy</a></li>
                        <li><a href="customer support.php">Customer Service</a></li>
                        <li><a href="index.php"><span>Search Terms</span></a></li>
                    </ul>
                </div>
                
                <div class="col_1_of_4 span_1_of_4">
                    <h4>My account</h4>
                    <ul>
                        <li><a href="carts.php">View Cart</a></li>
                        <!-- <li><a href="orderdetails.php">Track My Order</a></li> -->
                        <li><a href="login.php">User Login</a></li>
                        <li><a href="editprofile.php">Update profile</a></li>
                        <li><a href="adminlogin.php"><span>Admin login</span></a></li>
                    </ul>
                </div>
                <div class="col_1_of_4 span_1_of_4">
                    <h4>Mpeketoni Dukaletu Contact</h4>
                    <ul>
                         <li><i class="fas fa-envelope">  </i><a href="mailto:douglasnjuguna76@gmail.com">      douglasnjuguna76@gmail.com</a></li>
                         <li><i class="fas fa-phone"></i><a href="tel:+254732885177">  0768466612</a></li>
                         <li>P.O. Box 21-80503</li>
                         <li>Location: Mpeketoni</li>
                    </ul>
                   </div>
                   </div>
                 </div>
                <footer>
               <div class="footer-content">
                <ul class="socials">
                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                <li><a href="#"><i class="fab fa-youtube"></i></a></li>
            </ul>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024 Mpeketoni Duka letu. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
<style>

footer {
    background: #333;
    color: white;
    padding: 20px 0;
    text-align: center;
}

.footer-content {
    max-width: 1000px;
    margin: auto;
    padding: 0 20px;
}

.footer-content h3 {
    margin: 0;
    padding-bottom: 10px;
    font-size: 24px;
    text-transform: uppercase;
}

.footer-content p {
    margin: 0;
    padding-bottom: 20px;
    font-size: 16px;
    line-height: 1.5;
}

.footer-content .socials {
    list-style: none;
    padding: 0;
    display: flex;
    justify-content: center;
    gap: 15px;
}

.footer-content .socials li {
    display: inline-block;
}

.footer-content .socials li a {
    text-decoration: none;
    color: white;
    font-size: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    background: #555;
    border-radius: 50%;
    transition: background 0.3s ease;
}

.footer-content .socials li a:hover {
    background: #e91e63;
}

.footer-bottom {
    padding-top: 10px;
    font-size: 14px;
}
</style>