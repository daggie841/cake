<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
          
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
        }

        .content {
            flex: 0px;
        }

        #site_info {
            font-weight: bold;
            text-align: center;
            padding: 1px 0;
            background-color: #f1f1f1;
            display: flex;
            flex: 1px;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <div class="content">

    </div>
    <div id="site_info">
        <p>
            &copy; Copyright 2024 SIKAM FARM. All Rights Reserved.
        </p>
    </div>
</body>
</html>
