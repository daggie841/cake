<?php 
include_once'user-header.php'; 
include_once 'Cart.php';
?>

<div class="main">
    <div class="content">
        <div class="section group">
            <div class="psuccess">
                <h2>Success</h2>
         
                </p>
                <p>Thanks for your purchase.</p>
                <p>We will contact you soon with delivery details.</p>
                <p>Here are your order details...<a href="orderdetails.php"><i>Visit Here...</i></a></p>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

<style>
    .psuccess {
        width: 90%;
        max-width: 500px;
        min-height: 100px;
        text-align: center;
        border: 1px solid ;
        margin: 0 auto;
        padding: 20px;
        box-sizing: border-box;
    }

    .psuccess h2 {
        border-bottom: 5px solid orange;
        margin-bottom: 20px;
        padding-bottom: 10px;
    }

    .psuccess p {
        line-height: 1.5em;
        text-align: left;
        font-size: 14px;
    }

    @media (max-width: 768px) {
        .psuccess p {
            font-size: 12px;
        }
    }

    @media (max-width: 480px) {
        .psuccess {
            width: 95%;
            padding: 10px;
        }

        .psuccess h2 {
            font-size: 18px;
        }

        .psuccess p {
            font-size: 12px;
        }
    }
</style>
